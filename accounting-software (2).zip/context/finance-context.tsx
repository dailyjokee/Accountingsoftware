"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import type {
  Transaction,
  Account,
  FinancialSummary,
  TransactionType,
  TransactionCategory,
  Customer,
  Supplier,
  Invoice,
  Bill,
  Payment,
  InvoiceStatus,
  BalanceSheet,
  IncomeStatement,
  CashFlowStatement,
  InventoryItem,
  InventoryTransaction,
  InventoryCategory,
} from "@/lib/types"
import { v4 as uuidv4 } from "uuid"

interface FinanceContextType {
  // Transactions
  transactions: Transaction[]
  addTransaction: (transaction: Omit<Transaction, "id" | "createdAt">) => void
  deleteTransaction: (id: string) => void
  updateTransaction: (id: string, transaction: Partial<Transaction>) => void
  getTransactionsByType: (type: TransactionType) => Transaction[]
  getTransactionsByCategory: (category: TransactionCategory) => Transaction[]
  getTransactionsByDateRange: (startDate: string, endDate: string) => Transaction[]
  getTransactionsByRelatedId: (relatedId: string) => Transaction[]

  // Accounts
  accounts: Account[]
  addAccount: (account: Omit<Account, "id">) => void
  updateAccount: (id: string, account: Partial<Account>) => void
  deleteAccount: (id: string) => void

  // Customers
  customers: Customer[]
  addCustomer: (customer: Omit<Customer, "id" | "createdAt" | "balance">) => void
  updateCustomer: (id: string, customer: Partial<Customer>) => void
  deleteCustomer: (id: string) => void

  // Suppliers
  suppliers: Supplier[]
  addSupplier: (supplier: Omit<Supplier, "id" | "createdAt" | "balance">) => void
  updateSupplier: (id: string, supplier: Partial<Supplier>) => void
  deleteSupplier: (id: string) => void

  // Invoices
  invoices: Invoice[]
  addInvoice: (invoice: Omit<Invoice, "id" | "createdAt">) => void
  updateInvoice: (id: string, invoice: Partial<Invoice>) => void
  deleteInvoice: (id: string) => void
  getInvoicesByCustomer: (customerId: string) => Invoice[]
  getInvoicesByStatus: (status: InvoiceStatus) => Invoice[]

  // Bills
  bills: Bill[]
  addBill: (bill: Omit<Bill, "id" | "createdAt">) => void
  updateBill: (id: string, bill: Partial<Bill>) => void
  deleteBill: (id: string) => void
  getBillsBySupplier: (supplierId: string) => Bill[]
  getBillsByStatus: (status: InvoiceStatus) => Bill[]

  // Payments
  payments: Payment[]
  addPayment: (payment: Omit<Payment, "id" | "createdAt">) => void
  updatePayment: (id: string, payment: Partial<Payment>) => void
  deletePayment: (id: string) => void
  getPaymentsByRelated: (relatedId: string, relatedType: "invoice" | "bill") => Payment[]

  // Financial Reports
  summary: FinancialSummary
  refreshSummary: () => void
  generateBalanceSheet: () => BalanceSheet
  generateIncomeStatement: (startDate: string, endDate: string) => IncomeStatement
  generateCashFlowStatement: (startDate: string, endDate: string) => CashFlowStatement

  // Inventory
  inventoryItems: InventoryItem[]
  inventoryTransactions: InventoryTransaction[]
  addInventoryItem: (item: Omit<InventoryItem, "id" | "createdAt" | "lastUpdated">) => void
  updateInventoryItem: (id: string, item: Partial<InventoryItem>) => void
  deleteInventoryItem: (id: string) => void
  addInventoryTransaction: (transaction: Omit<InventoryTransaction, "id" | "createdAt">) => void
  getInventoryTransactionsByItem: (itemId: string) => InventoryTransaction[]
  getInventoryItemsByCategory: (category: InventoryCategory) => InventoryItem[]
  getInventoryItemsBySupplier: (supplierId: string) => InventoryItem[]
  getInventoryItemsLowStock: () => InventoryItem[]
}

const FinanceContext = createContext<FinanceContextType | undefined>(undefined)

export function useFinance() {
  const context = useContext(FinanceContext)
  if (context === undefined) {
    throw new Error("useFinance must be used within a FinanceProvider")
  }
  return context
}

export function FinanceProvider({ children }: { children: ReactNode }) {
  // State for all entities
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [accounts, setAccounts] = useState<Account[]>([])
  const [customers, setCustomers] = useState<Customer[]>([])
  const [suppliers, setSuppliers] = useState<Supplier[]>([])
  const [invoices, setInvoices] = useState<Invoice[]>([])
  const [bills, setBills] = useState<Bill[]>([])
  const [payments, setPayments] = useState<Payment[]>([])
  const [inventoryItems, setInventoryItems] = useState<InventoryItem[]>([])
  const [inventoryTransactions, setInventoryTransactions] = useState<InventoryTransaction[]>([])

  const [summary, setSummary] = useState<FinancialSummary>({
    totalIncome: 0,
    totalExpenses: 0,
    netProfit: 0,
    incomeByCategory: {},
    expensesByCategory: {},
    accountsReceivable: 0,
    accountsPayable: 0,
    monthlyData: [],
  })

  // Load data from localStorage on component mount
  useEffect(() => {
    const storedTransactions = localStorage.getItem("transactions")
    const storedAccounts = localStorage.getItem("accounts")
    const storedCustomers = localStorage.getItem("customers")
    const storedSuppliers = localStorage.getItem("suppliers")
    const storedInvoices = localStorage.getItem("invoices")
    const storedBills = localStorage.getItem("bills")
    const storedPayments = localStorage.getItem("payments")
    const storedInventoryItems = localStorage.getItem("inventoryItems")
    const storedInventoryTransactions = localStorage.getItem("inventoryTransactions")

    if (storedTransactions) {
      setTransactions(JSON.parse(storedTransactions))
    } else {
      setTransactions(getSampleTransactions())
    }

    if (storedAccounts) {
      setAccounts(JSON.parse(storedAccounts))
    } else {
      setAccounts(getSampleAccounts())
    }

    if (storedCustomers) {
      setCustomers(JSON.parse(storedCustomers))
    } else {
      setCustomers(getSampleCustomers())
    }

    if (storedSuppliers) {
      setSuppliers(JSON.parse(storedSuppliers))
    } else {
      setSuppliers(getSampleSuppliers())
    }

    if (storedInvoices) {
      setInvoices(JSON.parse(storedInvoices))
    } else {
      setInvoices(getSampleInvoices())
    }

    if (storedBills) {
      setBills(JSON.parse(storedBills))
    } else {
      setBills(getSampleBills())
    }

    if (storedPayments) {
      setPayments(JSON.parse(storedPayments))
    } else {
      setPayments(getSamplePayments())
    }

    if (storedInventoryItems) {
      setInventoryItems(JSON.parse(storedInventoryItems))
    } else {
      setInventoryItems(getSampleInventoryItems())
    }

    if (storedInventoryTransactions) {
      setInventoryTransactions(JSON.parse(storedInventoryTransactions))
    } else {
      setInventoryTransactions(getSampleInventoryTransactions())
    }
  }, [])

  // Save data to localStorage whenever it changes
  useEffect(() => {
    if (transactions.length > 0) {
      localStorage.setItem("transactions", JSON.stringify(transactions))
    }
  }, [transactions])

  useEffect(() => {
    if (accounts.length > 0) {
      localStorage.setItem("accounts", JSON.stringify(accounts))
    }
  }, [accounts])

  useEffect(() => {
    if (customers.length > 0) {
      localStorage.setItem("customers", JSON.stringify(customers))
    }
  }, [customers])

  useEffect(() => {
    if (suppliers.length > 0) {
      localStorage.setItem("suppliers", JSON.stringify(suppliers))
    }
  }, [suppliers])

  useEffect(() => {
    if (invoices.length > 0) {
      localStorage.setItem("invoices", JSON.stringify(invoices))
    }
  }, [invoices])

  useEffect(() => {
    if (bills.length > 0) {
      localStorage.setItem("bills", JSON.stringify(bills))
    }
  }, [bills])

  useEffect(() => {
    if (payments.length > 0) {
      localStorage.setItem("payments", JSON.stringify(payments))
    }
  }, [payments])

  useEffect(() => {
    if (inventoryItems.length > 0) {
      localStorage.setItem("inventoryItems", JSON.stringify(inventoryItems))
    }
  }, [inventoryItems])

  useEffect(() => {
    if (inventoryTransactions.length > 0) {
      localStorage.setItem("inventoryTransactions", JSON.stringify(inventoryTransactions))
    }
  }, [inventoryTransactions])

  // Calculate summary whenever relevant data changes
  useEffect(() => {
    refreshSummary()
  }, [transactions, invoices, bills])

  // Update customer balances when invoices or payments change
  useEffect(() => {
    updateCustomerBalances()
  }, [invoices, payments])

  // Update supplier balances when bills or payments change
  useEffect(() => {
    updateSupplierBalances()
  }, [bills, payments])

  // TRANSACTION FUNCTIONS
  const addTransaction = (transaction: Omit<Transaction, "id" | "createdAt">) => {
    const newTransaction: Transaction = {
      ...transaction,
      id: uuidv4(),
      createdAt: new Date().toISOString(),
    }

    setTransactions((prev) => [newTransaction, ...prev])

    // Update account balance
    if (
      transaction.type === "income" ||
      transaction.type === "expense" ||
      transaction.type === "sale" ||
      transaction.type === "purchase"
    ) {
      const accountToUpdate = accounts.find((a) => a.id === transaction.account)
      if (accountToUpdate) {
        const balanceChange =
          transaction.type === "income" || transaction.type === "sale" ? transaction.amount : -transaction.amount
        updateAccount(accountToUpdate.id, {
          balance: accountToUpdate.balance + balanceChange,
        })
      }
    }
  }

  const deleteTransaction = (id: string) => {
    const transaction = transactions.find((t) => t.id === id)
    if (!transaction) return

    setTransactions((prev) => prev.filter((t) => t.id !== id))

    // Revert account balance
    if (
      transaction.type === "income" ||
      transaction.type === "expense" ||
      transaction.type === "sale" ||
      transaction.type === "purchase"
    ) {
      const accountToUpdate = accounts.find((a) => a.id === transaction.account)
      if (accountToUpdate) {
        const balanceChange =
          transaction.type === "income" || transaction.type === "sale" ? -transaction.amount : transaction.amount
        updateAccount(accountToUpdate.id, {
          balance: accountToUpdate.balance + balanceChange,
        })
      }
    }
  }

  const updateTransaction = (id: string, transaction: Partial<Transaction>) => {
    const oldTransaction = transactions.find((t) => t.id === id)
    if (!oldTransaction) return

    setTransactions((prev) => prev.map((t) => (t.id === id ? { ...t, ...transaction } : t)))

    // Update account balance if amount, type, or account changed
    if (
      (transaction.amount !== undefined && transaction.amount !== oldTransaction.amount) ||
      (transaction.type !== undefined && transaction.type !== oldTransaction.type) ||
      (transaction.account !== undefined && transaction.account !== oldTransaction.account)
    ) {
      // Revert old transaction effect
      if (
        oldTransaction.type === "income" ||
        oldTransaction.type === "expense" ||
        oldTransaction.type === "sale" ||
        oldTransaction.type === "purchase"
      ) {
        const accountToUpdate = accounts.find((a) => a.id === oldTransaction.account)
        if (accountToUpdate) {
          const balanceChange =
            oldTransaction.type === "income" || oldTransaction.type === "sale"
              ? -oldTransaction.amount
              : oldTransaction.amount
          updateAccount(accountToUpdate.id, {
            balance: accountToUpdate.balance + balanceChange,
          })
        }
      }

      // Apply new transaction effect
      const newType = transaction.type || oldTransaction.type
      const newAmount = transaction.amount || oldTransaction.amount
      const newAccount = transaction.account || oldTransaction.account

      if (newType === "income" || newType === "expense" || newType === "sale" || newType === "purchase") {
        const accountToUpdate = accounts.find((a) => a.id === newAccount)
        if (accountToUpdate) {
          const balanceChange = newType === "income" || newType === "sale" ? newAmount : -newAmount
          updateAccount(accountToUpdate.id, {
            balance: accountToUpdate.balance + balanceChange,
          })
        }
      }
    }
  }

  const getTransactionsByType = (type: TransactionType) => {
    return transactions.filter((t) => t.type === type)
  }

  const getTransactionsByCategory = (category: TransactionCategory) => {
    return transactions.filter((t) => t.category === category)
  }

  const getTransactionsByDateRange = (startDate: string, endDate: string) => {
    return transactions.filter((t) => {
      return t.date >= startDate && t.date <= endDate
    })
  }

  const getTransactionsByRelatedId = (relatedId: string) => {
    return transactions.filter((t) => t.relatedId === relatedId)
  }

  // ACCOUNT FUNCTIONS
  const addAccount = (account: Omit<Account, "id">) => {
    const newAccount: Account = {
      ...account,
      id: uuidv4(),
    }
    setAccounts((prev) => [...prev, newAccount])
  }

  const updateAccount = (id: string, account: Partial<Account>) => {
    setAccounts((prev) => prev.map((a) => (a.id === id ? { ...a, ...account } : a)))
  }

  const deleteAccount = (id: string) => {
    // Check if account has transactions
    const hasTransactions = transactions.some((t) => t.account === id)
    if (hasTransactions) {
      alert("Cannot delete account with transactions. Please delete or move transactions first.")
      return
    }

    setAccounts((prev) => prev.filter((a) => a.id !== id))
  }

  // CUSTOMER FUNCTIONS
  const addCustomer = (customer: Omit<Customer, "id" | "createdAt" | "balance">) => {
    const newCustomer: Customer = {
      ...customer,
      id: uuidv4(),
      balance: 0,
      createdAt: new Date().toISOString(),
    }
    setCustomers((prev) => [...prev, newCustomer])
  }

  const updateCustomer = (id: string, customer: Partial<Customer>) => {
    setCustomers((prev) => prev.map((c) => (c.id === id ? { ...c, ...customer } : c)))
  }

  const deleteCustomer = (id: string) => {
    // Check if customer has invoices
    const hasInvoices = invoices.some((i) => i.customerId === id)
    if (hasInvoices) {
      alert("Cannot delete customer with invoices. Please delete invoices first.")
      return
    }

    setCustomers((prev) => prev.filter((c) => c.id !== id))
  }

  // SUPPLIER FUNCTIONS
  const addSupplier = (supplier: Omit<Supplier, "id" | "createdAt" | "balance">) => {
    const newSupplier: Supplier = {
      ...supplier,
      id: uuidv4(),
      balance: 0,
      createdAt: new Date().toISOString(),
    }
    setSuppliers((prev) => [...prev, newSupplier])
  }

  const updateSupplier = (id: string, supplier: Partial<Supplier>) => {
    setSuppliers((prev) => prev.map((s) => (s.id === id ? { ...s, ...supplier } : s)))
  }

  const deleteSupplier = (id: string) => {
    // Check if supplier has bills
    const hasBills = bills.some((b) => b.supplierId === id)
    if (hasBills) {
      alert("Cannot delete supplier with bills. Please delete bills first.")
      return
    }

    setSuppliers((prev) => prev.filter((s) => s.id !== id))
  }

  // INVOICE FUNCTIONS
  const addInvoice = (invoice: Omit<Invoice, "id" | "createdAt">) => {
    const newInvoice: Invoice = {
      ...invoice,
      id: uuidv4(),
      createdAt: new Date().toISOString(),
    }
    setInvoices((prev) => [...prev, newInvoice])

    // Create a transaction for the invoice if it's not a draft
    if (invoice.status !== "draft") {
      addTransaction({
        type: "sale",
        amount: invoice.total,
        date: invoice.issueDate,
        category: "sales",
        payee: customers.find((c) => c.id === invoice.customerId)?.name || "Unknown Customer",
        account: accounts[0]?.id || "", // Default to first account
        notes: `Invoice #${invoice.invoiceNumber}`,
        relatedId: newInvoice.id,
      })
    }
  }

  const updateInvoice = (id: string, invoice: Partial<Invoice>) => {
    const oldInvoice = invoices.find((i) => i.id === id)
    if (!oldInvoice) return

    setInvoices((prev) => prev.map((i) => (i.id === id ? { ...i, ...invoice } : i)))

    // Update or create transaction if status changed from draft to active
    if (oldInvoice.status === "draft" && invoice.status && invoice.status !== "draft") {
      const existingTransaction = transactions.find((t) => t.relatedId === id)

      if (!existingTransaction) {
        const updatedInvoice = { ...oldInvoice, ...invoice }
        addTransaction({
          type: "sale",
          amount: updatedInvoice.total,
          date: updatedInvoice.issueDate,
          category: "sales",
          payee: customers.find((c) => c.id === updatedInvoice.customerId)?.name || "Unknown Customer",
          account: accounts[0]?.id || "", // Default to first account
          notes: `Invoice #${updatedInvoice.invoiceNumber}`,
          relatedId: id,
        })
      }
    }

    // Update transaction if amount changed
    if (invoice.total !== undefined && invoice.total !== oldInvoice.total) {
      const existingTransaction = transactions.find((t) => t.relatedId === id)

      if (existingTransaction) {
        updateTransaction(existingTransaction.id, {
          amount: invoice.total,
        })
      }
    }
  }

  const deleteInvoice = (id: string) => {
    // Delete related transactions
    const relatedTransactions = transactions.filter((t) => t.relatedId === id)
    relatedTransactions.forEach((t) => deleteTransaction(t.id))

    // Delete related payments
    const relatedPayments = payments.filter((p) => p.relatedId === id && p.relatedType === "invoice")
    relatedPayments.forEach((p) => deletePayment(p.id))

    setInvoices((prev) => prev.filter((i) => i.id !== id))
  }

  const getInvoicesByCustomer = (customerId: string) => {
    return invoices.filter((i) => i.customerId === customerId)
  }

  const getInvoicesByStatus = (status: InvoiceStatus) => {
    return invoices.filter((i) => i.status === status)
  }

  // BILL FUNCTIONS
  const addBill = (bill: Omit<Bill, "id" | "createdAt">) => {
    const newBill: Bill = {
      ...bill,
      id: uuidv4(),
      createdAt: new Date().toISOString(),
    }
    setBills((prev) => [...prev, newBill])

    // Create a transaction for the bill if it's not a draft
    if (bill.status !== "draft") {
      addTransaction({
        type: "purchase",
        amount: bill.total,
        date: bill.issueDate,
        category: "inventory", // Default category, can be changed
        payee: suppliers.find((s) => s.id === bill.supplierId)?.name || "Unknown Supplier",
        account: accounts[0]?.id || "", // Default to first account
        notes: `Bill #${bill.billNumber}`,
        relatedId: newBill.id,
      })
    }
  }

  const updateBill = (id: string, bill: Partial<Bill>) => {
    const oldBill = bills.find((b) => b.id === id)
    if (!oldBill) return

    setBills((prev) => prev.map((b) => (b.id === id ? { ...b, ...bill } : b)))

    // Update or create transaction if status changed from draft to active
    if (oldBill.status === "draft" && bill.status && bill.status !== "draft") {
      const existingTransaction = transactions.find((t) => t.relatedId === id)

      if (!existingTransaction) {
        const updatedBill = { ...oldBill, ...bill }
        addTransaction({
          type: "purchase",
          amount: updatedBill.total,
          date: updatedBill.issueDate,
          category: "inventory", // Default category, can be changed
          payee: suppliers.find((s) => s.id === updatedBill.supplierId)?.name || "Unknown Supplier",
          account: accounts[0]?.id || "", // Default to first account
          notes: `Bill #${updatedBill.billNumber}`,
          relatedId: id,
        })
      }
    }

    // Update transaction if amount changed
    if (bill.total !== undefined && bill.total !== oldBill.total) {
      const existingTransaction = transactions.find((t) => t.relatedId === id)

      if (existingTransaction) {
        updateTransaction(existingTransaction.id, {
          amount: bill.total,
        })
      }
    }
  }

  const deleteBill = (id: string) => {
    // Delete related transactions
    const relatedTransactions = transactions.filter((t) => t.relatedId === id)
    relatedTransactions.forEach((t) => deleteTransaction(t.id))

    // Delete related payments
    const relatedPayments = payments.filter((p) => p.relatedId === id && p.relatedType === "bill")
    relatedPayments.forEach((p) => deletePayment(p.id))

    setBills((prev) => prev.filter((b) => b.id !== id))
  }

  const getBillsBySupplier = (supplierId: string) => {
    return bills.filter((b) => b.supplierId === supplierId)
  }

  const getBillsByStatus = (status: InvoiceStatus) => {
    return bills.filter((b) => b.status === status)
  }

  // PAYMENT FUNCTIONS
  const addPayment = (payment: Omit<Payment, "id" | "createdAt">) => {
    const newPayment: Payment = {
      ...payment,
      id: uuidv4(),
      createdAt: new Date().toISOString(),
    }
    setPayments((prev) => [...prev, newPayment])

    // Update invoice or bill
    if (payment.relatedType === "invoice") {
      const invoice = invoices.find((i) => i.id === payment.relatedId)
      if (invoice) {
        const newAmountPaid = invoice.amountPaid + payment.amount
        const newBalance = invoice.total - newAmountPaid
        let newStatus: InvoiceStatus = invoice.status

        if (newBalance <= 0) {
          newStatus = "paid"
        } else if (newAmountPaid > 0) {
          newStatus = "partial"
        }

        updateInvoice(invoice.id, {
          amountPaid: newAmountPaid,
          balance: newBalance,
          status: newStatus,
        })
      }
    } else if (payment.relatedType === "bill") {
      const bill = bills.find((b) => b.id === payment.relatedId)
      if (bill) {
        const newAmountPaid = bill.amountPaid + payment.amount
        const newBalance = bill.total - newAmountPaid
        let newStatus: InvoiceStatus = bill.status

        if (newBalance <= 0) {
          newStatus = "paid"
        } else if (newAmountPaid > 0) {
          newStatus = "partial"
        }

        updateBill(bill.id, {
          amountPaid: newAmountPaid,
          balance: newBalance,
          status: newStatus,
        })
      }
    }

    // Create transaction for the payment
    const isInvoicePayment = payment.relatedType === "invoice"
    const relatedEntity = isInvoicePayment
      ? invoices.find((i) => i.id === payment.relatedId)
      : bills.find((b) => b.id === payment.relatedId)

    if (relatedEntity) {
      const payeeName = isInvoicePayment
        ? customers.find((c) => c.id === (relatedEntity as Invoice).customerId)?.name || "Unknown Customer"
        : suppliers.find((s) => s.id === (relatedEntity as Bill).supplierId)?.name || "Unknown Supplier"

      const transactionType: TransactionType = isInvoicePayment ? "income" : "expense"
      const category: TransactionCategory = isInvoicePayment ? "sales" : "inventory"

      addTransaction({
        type: transactionType,
        amount: payment.amount,
        date: payment.date,
        category,
        payee: payeeName,
        account: payment.accountId,
        notes: `Payment for ${isInvoicePayment ? "Invoice" : "Bill"} #${
          isInvoicePayment ? (relatedEntity as Invoice).invoiceNumber : (relatedEntity as Bill).billNumber
        }`,
        relatedId: payment.id,
      })
    }
  }

  const updatePayment = (id: string, payment: Partial<Payment>) => {
    const oldPayment = payments.find((p) => p.id === id)
    if (!oldPayment) return

    // If amount changed, update related invoice/bill
    if (payment.amount !== undefined && payment.amount !== oldPayment.amount) {
      const amountDifference = payment.amount - oldPayment.amount

      if (oldPayment.relatedType === "invoice") {
        const invoice = invoices.find((i) => i.id === oldPayment.relatedId)
        if (invoice) {
          const newAmountPaid = invoice.amountPaid + amountDifference
          const newBalance = invoice.total - newAmountPaid
          let newStatus: InvoiceStatus = invoice.status

          if (newBalance <= 0) {
            newStatus = "paid"
          } else if (newAmountPaid > 0) {
            newStatus = "partial"
          } else {
            newStatus = "sent"
          }

          updateInvoice(invoice.id, {
            amountPaid: newAmountPaid,
            balance: newBalance,
            status: newStatus,
          })
        }
      } else if (oldPayment.relatedType === "bill") {
        const bill = bills.find((b) => b.id === oldPayment.relatedId)
        if (bill) {
          const newAmountPaid = bill.amountPaid + amountDifference
          const newBalance = bill.total - newAmountPaid
          let newStatus: InvoiceStatus = bill.status

          if (newBalance <= 0) {
            newStatus = "paid"
          } else if (newAmountPaid > 0) {
            newStatus = "partial"
          } else {
            newStatus = "sent"
          }

          updateBill(bill.id, {
            amountPaid: newAmountPaid,
            balance: newBalance,
            status: newStatus,
          })
        }
      }

      // Update related transaction
      const relatedTransaction = transactions.find((t) => t.relatedId === id)
      if (relatedTransaction) {
        updateTransaction(relatedTransaction.id, {
          amount: payment.amount,
        })
      }
    }

    setPayments((prev) => prev.map((p) => (p.id === id ? { ...p, ...payment } : p)))
  }

  const deletePayment = (id: string) => {
    const payment = payments.find((p) => p.id === id)
    if (!payment) return

    // Revert changes to invoice/bill
    if (payment.relatedType === "invoice") {
      const invoice = invoices.find((i) => i.id === payment.relatedId)
      if (invoice) {
        const newAmountPaid = invoice.amountPaid - payment.amount
        const newBalance = invoice.total - newAmountPaid
        let newStatus: InvoiceStatus = invoice.status

        if (newAmountPaid <= 0) {
          newStatus = "sent"
        } else if (newBalance > 0) {
          newStatus = "partial"
        }

        updateInvoice(invoice.id, {
          amountPaid: newAmountPaid,
          balance: newBalance,
          status: newStatus,
        })
      }
    } else if (payment.relatedType === "bill") {
      const bill = bills.find((b) => b.id === payment.relatedId)
      if (bill) {
        const newAmountPaid = bill.amountPaid - payment.amount
        const newBalance = bill.total - newAmountPaid
        let newStatus: InvoiceStatus = bill.status

        if (newAmountPaid <= 0) {
          newStatus = "sent"
        } else if (newBalance > 0) {
          newStatus = "partial"
        }

        updateBill(bill.id, {
          amountPaid: newAmountPaid,
          balance: newBalance,
          status: newStatus,
        })
      }
    }

    // Delete related transaction
    const relatedTransaction = transactions.find((t) => t.relatedId === id)
    if (relatedTransaction) {
      deleteTransaction(relatedTransaction.id)
    }

    setPayments((prev) => prev.filter((p) => p.id !== id))
  }

  const getPaymentsByRelated = (relatedId: string, relatedType: "invoice" | "bill") => {
    return payments.filter((p) => p.relatedId === relatedId && p.relatedType === relatedType)
  }

  // HELPER FUNCTIONS
  const updateCustomerBalances = () => {
    const updatedCustomers = [...customers]

    customers.forEach((customer, index) => {
      const customerInvoices = invoices.filter((i) => i.customerId === customer.id)
      const balance = customerInvoices.reduce((total, invoice) => total + invoice.balance, 0)
      updatedCustomers[index] = { ...customer, balance }
    })

    setCustomers(updatedCustomers)
  }

  const updateSupplierBalances = () => {
    const updatedSuppliers = [...suppliers]

    suppliers.forEach((supplier, index) => {
      const supplierBills = bills.filter((b) => b.supplierId === supplier.id)
      const balance = supplierBills.reduce((total, bill) => total + bill.balance, 0)
      updatedSuppliers[index] = { ...supplier, balance }
    })

    setSuppliers(updatedSuppliers)
  }

  // FINANCIAL REPORTS
  const refreshSummary = () => {
    const totalIncome = transactions
      .filter((t) => t.type === "income" || t.type === "sale")
      .reduce((sum, t) => sum + t.amount, 0)

    const totalExpenses = transactions
      .filter((t) => t.type === "expense" || t.type === "purchase")
      .reduce((sum, t) => sum + t.amount, 0)

    const netProfit = totalIncome - totalExpenses

    // Calculate income by category
    const incomeByCategory: Record<string, number> = {}
    transactions
      .filter((t) => t.type === "income" || t.type === "sale")
      .forEach((t) => {
        incomeByCategory[t.category] = (incomeByCategory[t.category] || 0) + t.amount
      })

    // Calculate expenses by category
    const expensesByCategory: Record<string, number> = {}
    transactions
      .filter((t) => t.type === "expense" || t.type === "purchase")
      .forEach((t) => {
        expensesByCategory[t.category] = (expensesByCategory[t.category] || 0) + t.amount
      })

    // Calculate accounts receivable and payable
    const accountsReceivable = invoices.reduce((sum, invoice) => sum + invoice.balance, 0)
    const accountsPayable = bills.reduce((sum, bill) => sum + bill.balance, 0)

    // Calculate monthly data
    const monthlyData: { month: string; income: number; expenses: number }[] = []
    const months: Record<string, { income: number; expenses: number }> = {}

    transactions.forEach((t) => {
      const month = t.date.substring(0, 7) // Format: YYYY-MM
      if (!months[month]) {
        months[month] = { income: 0, expenses: 0 }
      }

      if (t.type === "income" || t.type === "sale") {
        months[month].income += t.amount
      } else if (t.type === "expense" || t.type === "purchase") {
        months[month].expenses += t.amount
      }
    })

    Object.entries(months).forEach(([month, data]) => {
      monthlyData.push({
        month,
        income: data.income,
        expenses: data.expenses,
      })
    })

    // Sort by month
    monthlyData.sort((a, b) => a.month.localeCompare(b.month))

    setSummary({
      totalIncome,
      totalExpenses,
      netProfit,
      incomeByCategory,
      expensesByCategory,
      accountsReceivable,
      accountsPayable,
      monthlyData,
    })
  }

  const generateBalanceSheet = (): BalanceSheet => {
    // Calculate cash (sum of all account balances)
    const cash = accounts.reduce((sum, account) => sum + account.balance, 0)

    // Accounts receivable (sum of all unpaid invoices)
    const accountsReceivable = invoices.reduce((sum, invoice) => sum + invoice.balance, 0)

    // Accounts payable (sum of all unpaid bills)
    const accountsPayable = bills.reduce((sum, bill) => sum + bill.balance, 0)

    // For demo purposes, we'll use some placeholder values for other items
    const inventory = 5000
    const otherCurrentAssets = 1000
    const propertyAndEquipment = 10000
    const otherFixedAssets = 2000
    const shortTermDebt = 3000
    const otherCurrentLiabilities = 1000
    const longTermDebt = 5000
    const otherLongTermLiabilities = 0
    const capital = 15000

    // Calculate totals
    const totalCurrentAssets = cash + accountsReceivable + inventory + otherCurrentAssets
    const totalFixedAssets = propertyAndEquipment + otherFixedAssets
    const totalAssets = totalCurrentAssets + totalFixedAssets

    const totalCurrentLiabilities = accountsPayable + shortTermDebt + otherCurrentLiabilities
    const totalLongTermLiabilities = longTermDebt + otherLongTermLiabilities
    const totalLiabilities = totalCurrentLiabilities + totalLongTermLiabilities

    // Retained earnings is calculated as the difference to balance the sheet
    const retainedEarnings = totalAssets - totalLiabilities - capital
    const totalEquity = capital + retainedEarnings

    return {
      assets: {
        currentAssets: {
          cash,
          accountsReceivable,
          inventory,
          otherCurrentAssets,
          totalCurrentAssets,
        },
        fixedAssets: {
          propertyAndEquipment,
          otherFixedAssets,
          totalFixedAssets,
        },
        totalAssets,
      },
      liabilities: {
        currentLiabilities: {
          accountsPayable,
          shortTermDebt,
          otherCurrentLiabilities,
          totalCurrentLiabilities,
        },
        longTermLiabilities: {
          longTermDebt,
          otherLongTermLiabilities,
          totalLongTermLiabilities,
        },
        totalLiabilities,
      },
      equity: {
        capital,
        retainedEarnings,
        totalEquity,
      },
    }
  }

  const generateIncomeStatement = (startDate: string, endDate: string): IncomeStatement => {
    // Filter transactions within the date range
    const periodTransactions = transactions.filter((t) => t.date >= startDate && t.date <= endDate)

    // Calculate sales revenue
    const sales = periodTransactions.filter((t) => t.type === "sale").reduce((sum, t) => sum + t.amount, 0)

    // Calculate other income
    const otherIncome = periodTransactions
      .filter((t) => t.type === "income" && t.category !== "sales")
      .reduce((sum, t) => sum + t.amount, 0)

    // Calculate cost of goods sold
    const costOfGoodsSold = periodTransactions
      .filter((t) => t.type === "purchase" && t.category === "inventory")
      .reduce((sum, t) => sum + t.amount, 0)

    // Calculate operating expenses by category
    const operatingExpenses: Record<string, number> = {}
    periodTransactions
      .filter((t) => t.type === "expense" && t.category !== "inventory")
      .forEach((t) => {
        operatingExpenses[t.category] = (operatingExpenses[t.category] || 0) + t.amount
      })

    // Calculate totals
    const totalRevenue = sales + otherIncome
    const totalOperatingExpenses = Object.values(operatingExpenses).reduce((sum, amount) => sum + amount, 0)
    const totalExpenses = costOfGoodsSold + totalOperatingExpenses

    const grossProfit = totalRevenue - costOfGoodsSold
    const operatingIncome = grossProfit - totalOperatingExpenses
    const netIncome = operatingIncome // Assuming no other income/expenses for simplicity

    return {
      revenue: {
        sales,
        otherIncome,
        totalRevenue,
      },
      expenses: {
        costOfGoodsSold,
        operatingExpenses,
        totalOperatingExpenses,
        totalExpenses,
      },
      grossProfit,
      operatingIncome,
      netIncome,
    }
  }

  const generateCashFlowStatement = (startDate: string, endDate: string): CashFlowStatement => {
    // Get income statement for the period
    const incomeStatement = generateIncomeStatement(startDate, endDate)

    // Filter transactions within the date range
    const periodTransactions = transactions.filter((t) => t.date >= startDate && t.date <= endDate)

    // For demo purposes, we'll use some placeholder values for adjustments and changes
    const adjustments: Record<string, number> = {
      depreciation: 500,
      amortization: 200,
    }

    const changeInWorkingCapital: Record<string, number> = {
      accountsReceivable: -1000, // Negative means increase in receivables (cash outflow)
      inventory: -500,
      accountsPayable: 800, // Positive means increase in payables (cash inflow)
    }

    // Calculate net cash from operating
    const totalAdjustments = Object.values(adjustments).reduce((sum, amount) => sum + amount, 0)
    const totalChangeInWorkingCapital = Object.values(changeInWorkingCapital).reduce((sum, amount) => sum + amount, 0)
    const netCashFromOperating = incomeStatement.netIncome + totalAdjustments + totalChangeInWorkingCapital

    // For demo purposes, we'll use placeholder values for investing and financing
    const investingActivities: Record<string, number> = {
      purchaseOfEquipment: -2000,
      saleOfAssets: 500,
    }

    const financingActivities: Record<string, number> = {
      debtRepayment: -1000,
      dividendsPaid: -500,
    }

    // Calculate totals
    const netCashFromInvesting = Object.values(investingActivities).reduce((sum, amount) => sum + amount, 0)
    const netCashFromFinancing = Object.values(financingActivities).reduce((sum, amount) => sum + amount, 0)

    const netCashChange = netCashFromOperating + netCashFromInvesting + netCashFromFinancing

    // Get starting and ending cash
    // For simplicity, we'll use the current account balances and calculate backwards
    const endingCash = accounts.reduce((sum, account) => sum + account.balance, 0)
    const startingCash = endingCash - netCashChange

    return {
      operatingActivities: {
        netIncome: incomeStatement.netIncome,
        adjustments,
        changeInWorkingCapital,
        netCashFromOperating,
      },
      investingActivities: {
        items: investingActivities,
        netCashFromInvesting,
      },
      financingActivities: {
        items: financingActivities,
        netCashFromFinancing,
      },
      netCashChange,
      startingCash,
      endingCash,
    }
  }

  // SAMPLE DATA FUNCTIONS
  const getSampleTransactions = (): Transaction[] => {
    return [
      {
        id: uuidv4(),
        type: "income",
        amount: 3200,
        date: "2023-03-15",
        category: "salary",
        payee: "ABC Corp",
        account: "checking-1",
        notes: "Monthly salary",
        createdAt: "2023-03-15T10:00:00Z",
      },
      {
        id: uuidv4(),
        type: "expense",
        amount: 1200,
        date: "2023-03-22",
        category: "rent",
        payee: "Landlord",
        account: "checking-1",
        notes: "Monthly rent",
        createdAt: "2023-03-22T14:30:00Z",
      },
      {
        id: uuidv4(),
        type: "expense",
        amount: 135.22,
        date: "2023-04-01",
        category: "utilities",
        payee: "Electric Company",
        account: "checking-1",
        notes: "Electricity bill",
        createdAt: "2023-04-01T09:15:00Z",
      },
      {
        id: uuidv4(),
        type: "sale",
        amount: 1500,
        date: "2023-04-03",
        category: "sales",
        payee: "XYZ Ltd",
        account: "checking-1",
        notes: "Invoice #1001",
        createdAt: "2023-04-03T16:45:00Z",
        relatedId: "invoice-1",
      },
      {
        id: uuidv4(),
        type: "purchase",
        amount: 242,
        date: "2023-04-05",
        category: "inventory",
        payee: "Office Supplies Inc",
        account: "checking-1",
        notes: "Bill #1001",
        createdAt: "2023-04-05T11:20:00Z",
        relatedId: "bill-1",
      },
      {
        id: uuidv4(),
        type: "sale",
        amount: 2750,
        date: "2023-03-25",
        category: "sales",
        payee: "DEF Inc",
        account: "savings-1",
        notes: "Invoice #1002",
        createdAt: "2023-03-25T13:10:00Z",
        relatedId: "invoice-2",
      },
      {
        id: uuidv4(),
        type: "expense",
        amount: 49.99,
        date: "2023-03-28",
        category: "software",
        payee: "Software Co",
        account: "credit-1",
        notes: "Monthly subscription",
        createdAt: "2023-03-28T08:30:00Z",
      },
    ]
  }

  const getSampleAccounts = (): Account[] => {
    return [
      {
        id: "checking-1",
        name: "Main Checking",
        type: "checking",
        balance: 3122.79,
      },
      {
        id: "savings-1",
        name: "Savings Account",
        type: "savings",
        balance: 8500,
      },
      {
        id: "credit-1",
        name: "Credit Card",
        type: "credit",
        balance: -450.22,
      },
      {
        id: "cash-1",
        name: "Cash",
        type: "cash",
        balance: 150,
      },
    ]
  }

  const getSampleCustomers = (): Customer[] => {
    return [
      {
        id: "customer-1",
        name: "XYZ Ltd",
        email: "accounts@xyzltd.com",
        phone: "555-123-4567",
        address: "123 Business Ave, Suite 100, Business City, BC 12345",
        notes: "Key client since 2020",
        balance: 1500,
        createdAt: "2023-01-15T10:00:00Z",
      },
      {
        id: "customer-2",
        name: "DEF Inc",
        email: "billing@definc.com",
        phone: "555-987-6543",
        address: "456 Corporate Blvd, Enterprise City, EC 67890",
        notes: "Prefers electronic invoices",
        balance: 2750,
        createdAt: "2023-02-20T14:30:00Z",
      },
      {
        id: "customer-3",
        name: "GHI Corporation",
        email: "finance@ghicorp.com",
        phone: "555-456-7890",
        address: "789 Industry Road, Commerce Town, CT 54321",
        notes: "Net 30 payment terms",
        balance: 0,
        createdAt: "2023-03-10T09:15:00Z",
      },
    ]
  }

  const getSampleSuppliers = (): Supplier[] => {
    return [
      {
        id: "supplier-1",
        name: "Office Supplies Inc",
        email: "sales@officesupplies.com",
        phone: "555-222-3333",
        address: "100 Vendor Street, Supply City, SC 11111",
        notes: "Bulk discounts available",
        balance: 242,
        createdAt: "2023-01-10T11:00:00Z",
      },
      {
        id: "supplier-2",
        name: "Tech Distributors",
        email: "orders@techdist.com",
        phone: "555-444-5555",
        address: "200 Distribution Lane, Tech City, TC 22222",
        notes: "Requires 50% deposit on orders over $1000",
        balance: 0,
        createdAt: "2023-02-15T13:45:00Z",
      },
      {
        id: "supplier-3",
        name: "Global Shipping Co",
        email: "support@globalshipping.com",
        phone: "555-666-7777",
        address: "300 Logistics Blvd, Port City, PC 33333",
        notes: "Ships internationally",
        balance: 0,
        createdAt: "2023-03-05T10:30:00Z",
      },
    ]
  }

  const getSampleInvoices = (): Invoice[] => {
    return [
      {
        id: "invoice-1",
        customerId: "customer-1",
        invoiceNumber: "1001",
        issueDate: "2023-04-01",
        dueDate: "2023-05-01",
        items: [
          {
            id: uuidv4(),
            description: "Web Development Services",
            quantity: 10,
            unitPrice: 150,
            taxRate: 0,
            total: 1500,
          },
        ],
        subtotal: 1500,
        taxTotal: 0,
        total: 1500,
        amountPaid: 0,
        balance: 1500,
        status: "sent",
        notes: "Payment due within 30 days",
        createdAt: "2023-04-01T09:00:00Z",
      },
      {
        id: "invoice-2",
        customerId: "customer-2",
        invoiceNumber: "1002",
        issueDate: "2023-03-25",
        dueDate: "2023-04-24",
        items: [
          {
            id: uuidv4(),
            description: "Mobile App Development",
            quantity: 1,
            unitPrice: 2500,
            taxRate: 10,
            total: 2750,
          },
        ],
        subtotal: 2500,
        taxTotal: 250,
        total: 2750,
        amountPaid: 0,
        balance: 2750,
        status: "sent",
        notes: "Payment due within 30 days",
        createdAt: "2023-03-25T11:30:00Z",
      },
    ]
  }

  const getSampleBills = (): Bill[] => {
    return [
      {
        id: "bill-1",
        supplierId: "supplier-1",
        billNumber: "1001",
        issueDate: "2023-04-05",
        dueDate: "2023-05-05",
        items: [
          {
            id: uuidv4(),
            description: "Office Supplies",
            quantity: 1,
            unitPrice: 242,
            taxRate: 0,
            total: 242,
          },
        ],
        subtotal: 242,
        taxTotal: 0,
        total: 242,
        amountPaid: 0,
        balance: 242,
        status: "sent",
        notes: "Net 30 terms",
        createdAt: "2023-04-05T10:15:00Z",
      },
    ]
  }

  const getSamplePayments = (): Payment[] => {
    return []
  }

  const getSampleInventoryItems = (): InventoryItem[] => {
    const now = new Date().toISOString()
    return [
      {
        id: uuidv4(),
        name: "Office Desk",
        sku: "DESK-001",
        description: "Standard office desk, 60x30 inches",
        category: "finished_goods",
        quantity: 15,
        unitCost: 120,
        sellingPrice: 249.99,
        reorderPoint: 5,
        location: "Warehouse A",
        supplier: "supplier-1",
        lastUpdated: now,
        createdAt: now,
      },
      {
        id: uuidv4(),
        name: "Office Chair",
        sku: "CHAIR-001",
        description: "Ergonomic office chair with adjustable height",
        category: "finished_goods",
        quantity: 25,
        unitCost: 85,
        sellingPrice: 179.99,
        reorderPoint: 8,
        location: "Warehouse A",
        supplier: "supplier-1",
        lastUpdated: now,
        createdAt: now,
      },
      {
        id: uuidv4(),
        name: "Printer Paper",
        sku: "PAPER-001",
        description: "A4 printer paper, 500 sheets per ream",
        category: "supplies",
        quantity: 50,
        unitCost: 3.5,
        sellingPrice: 5.99,
        reorderPoint: 20,
        location: "Storage Room B",
        supplier: "supplier-2",
        lastUpdated: now,
        createdAt: now,
      },
    ]
  }

  const getSampleInventoryTransactions = (): InventoryTransaction[] => {
    return []
  }

  const addInventoryItem = (item: Omit<InventoryItem, "id" | "createdAt" | "lastUpdated">) => {
    const now = new Date().toISOString()
    const newItem: InventoryItem = {
      ...item,
      id: uuidv4(),
      createdAt: now,
      lastUpdated: now,
    }
    setInventoryItems((prev) => [...prev, newItem])
  }

  const updateInventoryItem = (id: string, item: Partial<InventoryItem>) => {
    setInventoryItems((prev) =>
      prev.map((i) => {
        if (i.id === id) {
          return {
            ...i,
            ...item,
            lastUpdated: new Date().toISOString(),
          }
        }
        return i
      }),
    )
  }

  const deleteInventoryItem = (id: string) => {
    // Check if item has transactions
    const hasTransactions = inventoryTransactions.some((t) => t.itemId === id)
    if (hasTransactions) {
      throw new Error("Cannot delete item with transactions. Please delete transactions first.")
    }

    setInventoryItems((prev) => prev.filter((i) => i.id !== id))
  }

  const addInventoryTransaction = (transaction: Omit<InventoryTransaction, "id" | "createdAt">) => {
    const newTransaction: InventoryTransaction = {
      ...transaction,
      id: uuidv4(),
      createdAt: new Date().toISOString(),
    }
    setInventoryTransactions((prev) => [...prev, newTransaction])

    // Update item quantity
    const item = inventoryItems.find((i) => i.id === transaction.itemId)
    if (item) {
      let quantityChange = 0

      if (transaction.type === "purchase") {
        quantityChange = transaction.quantity
      } else if (transaction.type === "sale") {
        quantityChange = -transaction.quantity
      } else if (transaction.type === "adjustment") {
        quantityChange = transaction.quantity
      }

      updateInventoryItem(item.id, {
        quantity: item.quantity + quantityChange,
      })
    }
  }

  const getInventoryTransactionsByItem = (itemId: string) => {
    return inventoryTransactions.filter((t) => t.itemId === itemId)
  }

  const getInventoryItemsByCategory = (category: InventoryCategory) => {
    return inventoryItems.filter((i) => i.category === category)
  }

  const getInventoryItemsBySupplier = (supplierId: string) => {
    return inventoryItems.filter((i) => i.supplier === supplierId)
  }

  const getInventoryItemsLowStock = () => {
    return inventoryItems.filter((i) => i.quantity <= i.reorderPoint)
  }

  return (
    <FinanceContext.Provider
      value={{
        // Transactions
        transactions,
        addTransaction,
        deleteTransaction,
        updateTransaction,
        getTransactionsByType,
        getTransactionsByCategory,
        getTransactionsByDateRange,
        getTransactionsByRelatedId,

        // Accounts
        accounts,
        addAccount,
        updateAccount,
        deleteAccount,

        // Customers
        customers,
        addCustomer,
        updateCustomer,
        deleteCustomer,

        // Suppliers
        suppliers,
        addSupplier,
        updateSupplier,
        deleteSupplier,

        // Invoices
        invoices,
        addInvoice,
        updateInvoice,
        deleteInvoice,
        getInvoicesByCustomer,
        getInvoicesByStatus,

        // Bills
        bills,
        addBill,
        updateBill,
        deleteBill,
        getBillsBySupplier,
        getBillsByStatus,

        // Payments
        payments,
        addPayment,
        updatePayment,
        deletePayment,
        getPaymentsByRelated,

        // Financial Reports
        summary,
        refreshSummary,
        generateBalanceSheet,
        generateIncomeStatement,
        generateCashFlowStatement,
        inventoryItems,
        inventoryTransactions,
        addInventoryItem,
        updateInventoryItem,
        deleteInventoryItem,
        addInventoryTransaction,
        getInventoryTransactionsByItem,
        getInventoryItemsByCategory,
        getInventoryItemsBySupplier,
        getInventoryItemsLowStock,
      }}
    >
      {children}
    </FinanceContext.Provider>
  )
}

