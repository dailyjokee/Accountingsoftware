export type TransactionType = "income" | "expense" | "transfer" | "sale" | "purchase"
export type TransactionCategory =
  | "salary"
  | "freelance"
  | "interest"
  | "other_income"
  | "sales" // Income categories
  | "rent"
  | "utilities"
  | "groceries"
  | "entertainment"
  | "transportation"
  | "office_supplies"
  | "software"
  | "inventory"
  | "other_expense" // Expense categories

export type InvoiceStatus = "draft" | "sent" | "paid" | "overdue" | "cancelled" | "partial"
export type PaymentMethod = "cash" | "bank_transfer" | "credit_card" | "check" | "other"

export interface Transaction {
  id: string
  type: TransactionType
  amount: number
  date: string
  category: TransactionCategory
  payee: string
  account: string
  notes?: string
  createdAt: string
  relatedId?: string // Reference to invoice, bill, etc.
}

export interface Account {
  id: string
  name: string
  type: "checking" | "savings" | "credit" | "cash"
  balance: number
}

export interface Customer {
  id: string
  name: string
  email: string
  phone?: string
  address?: string
  notes?: string
  balance: number // Amount customer owes (receivables)
  createdAt: string
}

export interface Supplier {
  id: string
  name: string
  email: string
  phone?: string
  address?: string
  notes?: string
  balance: number // Amount owed to supplier (payables)
  createdAt: string
}

export interface InvoiceItem {
  id: string
  description: string
  quantity: number
  unitPrice: number
  taxRate: number
  total: number
}

export interface Invoice {
  id: string
  customerId: string
  invoiceNumber: string
  issueDate: string
  dueDate: string
  items: InvoiceItem[]
  subtotal: number
  taxTotal: number
  total: number
  amountPaid: number
  balance: number
  status: InvoiceStatus
  notes?: string
  createdAt: string
}

export interface Bill {
  id: string
  supplierId: string
  billNumber: string
  issueDate: string
  dueDate: string
  items: InvoiceItem[] // Reusing the same structure
  subtotal: number
  taxTotal: number
  total: number
  amountPaid: number
  balance: number
  status: InvoiceStatus
  notes?: string
  createdAt: string
}

export interface Payment {
  id: string
  date: string
  amount: number
  method: PaymentMethod
  relatedId: string // Invoice or bill ID
  relatedType: "invoice" | "bill"
  accountId: string
  notes?: string
  createdAt: string
}

export interface FinancialSummary {
  totalIncome: number
  totalExpenses: number
  netProfit: number
  incomeByCategory: Record<string, number>
  expensesByCategory: Record<string, number>
  accountsReceivable: number
  accountsPayable: number
  monthlyData: {
    month: string
    income: number
    expenses: number
  }[]
}

export interface BalanceSheet {
  assets: {
    currentAssets: {
      cash: number
      accountsReceivable: number
      inventory: number
      otherCurrentAssets: number
      totalCurrentAssets: number
    }
    fixedAssets: {
      propertyAndEquipment: number
      otherFixedAssets: number
      totalFixedAssets: number
    }
    totalAssets: number
  }
  liabilities: {
    currentLiabilities: {
      accountsPayable: number
      shortTermDebt: number
      otherCurrentLiabilities: number
      totalCurrentLiabilities: number
    }
    longTermLiabilities: {
      longTermDebt: number
      otherLongTermLiabilities: number
      totalLongTermLiabilities: number
    }
    totalLiabilities: number
  }
  equity: {
    capital: number
    retainedEarnings: number
    totalEquity: number
  }
}

export interface IncomeStatement {
  revenue: {
    sales: number
    otherIncome: number
    totalRevenue: number
  }
  expenses: {
    costOfGoodsSold: number
    operatingExpenses: Record<string, number>
    totalOperatingExpenses: number
    totalExpenses: number
  }
  grossProfit: number
  operatingIncome: number
  netIncome: number
}

export interface CashFlowStatement {
  operatingActivities: {
    netIncome: number
    adjustments: Record<string, number>
    changeInWorkingCapital: Record<string, number>
    netCashFromOperating: number
  }
  investingActivities: {
    items: Record<string, number>
    netCashFromInvesting: number
  }
  financingActivities: {
    items: Record<string, number>
    netCashFromFinancing: number
  }
  netCashChange: number
  startingCash: number
  endingCash: number
}

export type InventoryCategory =
  | "raw_materials"
  | "finished_goods"
  | "work_in_progress"
  | "merchandise"
  | "supplies"
  | "other"

export interface InventoryItem {
  id: string
  name: string
  sku: string
  description?: string
  category: InventoryCategory
  quantity: number
  unitCost: number
  sellingPrice: number
  reorderPoint: number
  location?: string
  supplier?: string
  lastUpdated: string
  createdAt: string
}

export interface InventoryTransaction {
  id: string
  itemId: string
  type: "purchase" | "sale" | "adjustment" | "transfer"
  quantity: number
  date: string
  reference?: string
  notes?: string
  createdAt: string
}

