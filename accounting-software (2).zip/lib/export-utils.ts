import FileSaver from "file-saver"

export function exportToCSV<T extends Record<string, any>>(
  data: T[],
  columns: { key: keyof T; label: string }[],
  filename: string,
) {
  // Create CSV header row
  const header = columns.map((col) => col.label).join(",")

  // Create CSV data rows
  const csvData = data
    .map((row) => {
      return columns
        .map((col) => {
          const value = row[col.key]
          // Handle values that might contain commas or quotes
          if (value === null || value === undefined) {
            return ""
          }
          const stringValue = String(value)
          if (stringValue.includes(",") || stringValue.includes('"') || stringValue.includes("\n")) {
            return `"${stringValue.replace(/"/g, '""')}"`
          }
          return stringValue
        })
        .join(",")
    })
    .join("\n")

  // Combine header and data
  const csv = `${header}\n${csvData}`

  // Create a Blob and download the file
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" })
  FileSaver.saveAs(blob, `${filename}.csv`)
}

export function printCurrentView() {
  window.print()
}

