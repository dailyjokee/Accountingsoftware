"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Home,
  BarChart3,
  CreditCard,
  DollarSign,
  Package,
  Users,
  FileText,
  ShoppingCart,
  Menu,
  LogOut,
  Settings,
  User,
  Wallet,
} from "lucide-react"

export function Header() {
  const pathname = usePathname()

  const isActive = (path: string) => {
    return pathname === path || pathname.startsWith(`${path}/`)
  }

  const navItems = [
    { name: "Dashboard", path: "/", icon: Home },
    { name: "Transactions", path: "/transactions", icon: CreditCard },
    { name: "Accounts", path: "/accounts", icon: DollarSign },
    { name: "Customers", path: "/customers", icon: Users },
    { name: "Sales", path: "/sales", icon: FileText },
    { name: "Purchases", path: "/purchases", icon: ShoppingCart },
    { name: "Inventory", path: "/inventory", icon: Package },
    { name: "Payments", path: "/payments", icon: Wallet },
    { name: "Reports", path: "/reports", icon: BarChart3 },
  ]

  return (
    <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-background px-4 md:px-6">
      <Link href="/" className="flex items-center gap-2 font-semibold">
        <DollarSign className="h-6 w-6" />
        <span className="hidden md:inline-block">Accounting Software</span>
      </Link>
      <nav className="hidden flex-1 md:block">
        <ul className="flex gap-4">
          {navItems.map((item) => (
            <li key={item.path}>
              <Button
                asChild
                variant={isActive(item.path) ? "default" : "ghost"}
                className={isActive(item.path) ? "bg-primary text-primary-foreground" : ""}
                size="sm"
              >
                <Link href={item.path} className="flex items-center gap-2">
                  <item.icon className="h-4 w-4" />
                  {item.name}
                </Link>
              </Button>
            </li>
          ))}
        </ul>
      </nav>
      <div className="flex flex-1 items-center justify-end gap-4 md:hidden">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="icon">
              <Menu className="h-5 w-5" />
              <span className="sr-only">Toggle menu</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Navigation</DropdownMenuLabel>
            <DropdownMenuSeparator />
            {navItems.map((item) => (
              <DropdownMenuItem key={item.path} asChild>
                <Link href={item.path} className="flex w-full items-center gap-2">
                  <item.icon className="h-4 w-4" />
                  {item.name}
                </Link>
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="icon" className="rounded-full">
            <User className="h-5 w-5" />
            <span className="sr-only">Toggle user menu</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuLabel>My Account</DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem>
            <Settings className="mr-2 h-4 w-4" />
            Settings
          </DropdownMenuItem>
          <DropdownMenuItem>
            <LogOut className="mr-2 h-4 w-4" />
            Logout
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </header>
  )
}

