"use client"

import { Button } from "@/components/ui/button"
import { Printer } from "lucide-react"
import { printCurrentView } from "@/lib/export-utils"

interface PrintButtonProps {
  variant?: "default" | "outline" | "secondary" | "ghost" | "link" | "destructive"
  size?: "default" | "sm" | "lg" | "icon"
}

export function PrintButton({ variant = "outline", size = "sm" }: PrintButtonProps) {
  return (
    <Button variant={variant} size={size} onClick={printCurrentView}>
      <Printer className="mr-2 h-4 w-4" />
      Print
    </Button>
  )
}

