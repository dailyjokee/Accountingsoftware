"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useFinance } from "@/context/finance-context"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Plus, Search, Trash2, Edit } from "lucide-react"
import { formatCurrency, formatDate, getCategoryLabel } from "@/lib/utils"
import type { Transaction, TransactionType } from "@/lib/types"
// Import the ExportButton component
import { ExportButton } from "@/components/export-button"
import { useRouter } from "next/navigation"

export default function TransactionsPage() {
  const { transactions, accounts, deleteTransaction } = useFinance()
  const [filteredTransactions, setFilteredTransactions] = useState<Transaction[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [timeFilter, setTimeFilter] = useState("30")
  const [currentPage, setCurrentPage] = useState(1)
  const [transactionsPerPage] = useState(10)
  const [isClient, setIsClient] = useState(false)
  const router = useRouter()

  // Fix for hydration issues
  useEffect(() => {
    setIsClient(true)
  }, [])

  useEffect(() => {
    let filtered = [...transactions]

    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (t) =>
          t.payee.toLowerCase().includes(query) ||
          t.notes?.toLowerCase().includes(query) ||
          t.category.toLowerCase().includes(query),
      )
    }

    // Apply category filter
    if (categoryFilter !== "all") {
      filtered = filtered.filter((t) => t.type === categoryFilter)
    }

    // Apply time filter
    const now = new Date()
    const pastDate = new Date()

    if (timeFilter === "7") {
      pastDate.setDate(now.getDate() - 7)
    } else if (timeFilter === "30") {
      pastDate.setDate(now.getDate() - 30)
    } else if (timeFilter === "90") {
      pastDate.setDate(now.getDate() - 90)
    } else if (timeFilter === "year") {
      pastDate.setFullYear(now.getFullYear() - 1)
    }

    filtered = filtered.filter((t) => new Date(t.date) >= pastDate)

    // Sort by date (newest first)
    filtered.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())

    setFilteredTransactions(filtered)
    setCurrentPage(1) // Reset to first page when filters change
  }, [transactions, searchQuery, categoryFilter, timeFilter])

  // Get current transactions for pagination
  const indexOfLastTransaction = currentPage * transactionsPerPage
  const indexOfFirstTransaction = indexOfLastTransaction - transactionsPerPage
  const currentTransactions = filteredTransactions.slice(indexOfFirstTransaction, indexOfLastTransaction)
  const totalPages = Math.ceil(filteredTransactions.length / transactionsPerPage)

  const handleDeleteTransaction = (id: string) => {
    deleteTransaction(id)
  }

  const getAccountName = (accountId: string) => {
    const account = accounts.find((a) => a.id === accountId)
    return account ? account.name : "Unknown Account"
  }

  const getCategoryBadgeClass = (type: TransactionType) => {
    if (type === "income") {
      return "inline-flex items-center rounded-md bg-green-50 px-2 py-1 text-xs font-medium text-green-700 ring-1 ring-inset ring-green-600/20"
    } else if (type === "expense") {
      return "inline-flex items-center rounded-md bg-red-50 px-2 py-1 text-xs font-medium text-red-700 ring-1 ring-inset ring-red-600/10"
    } else {
      return "inline-flex items-center rounded-md bg-blue-50 px-2 py-1 text-xs font-medium text-blue-700 ring-1 ring-inset ring-blue-600/20"
    }
  }

  const handleEditTransaction = (id: string) => {
    router.push(`/edit-transaction/${id}`)
  }

  return (
    <div className="flex min-h-screen w-full flex-col">
      <Header />
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-semibold md:text-2xl">Transactions</h1>
          <div className="flex items-center gap-2">
            <ExportButton
              data={filteredTransactions}
              columns={[
                { key: "date", label: "Date" },
                { key: "type", label: "Type" },
                { key: "category", label: "Category" },
                { key: "payee", label: "Payee" },
                { key: "amount", label: "Amount" },
                { key: "notes", label: "Notes" },
              ]}
              filename="transactions"
            />
            <Link href="/add-transaction">
              <Button size="sm">
                <Plus className="mr-2 h-4 w-4" />
                Add Transaction
              </Button>
            </Link>
          </div>
        </div>
        <Card>
          <CardHeader>
            <CardTitle>Transaction History</CardTitle>
            <CardDescription>View and manage all your financial transactions.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-4">
              <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      type="search"
                      placeholder="Search transactions..."
                      className="pl-8 sm:w-[300px] md:w-[200px] lg:w-[300px]"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
                <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
                  <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                    <SelectTrigger className="w-full sm:w-[150px]">
                      <SelectValue placeholder="Category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      <SelectItem value="income">Income</SelectItem>
                      <SelectItem value="expense">Expenses</SelectItem>
                      <SelectItem value="transfer">Transfers</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={timeFilter} onValueChange={setTimeFilter}>
                    <SelectTrigger className="w-full sm:w-[180px]">
                      <SelectValue placeholder="Time period" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="7">Last 7 days</SelectItem>
                      <SelectItem value="30">Last 30 days</SelectItem>
                      <SelectItem value="90">Last 90 days</SelectItem>
                      <SelectItem value="year">This year</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              {isClient && (
                <div className="rounded-md border">
                  <div className="grid grid-cols-6 gap-4 p-4 text-sm font-medium">
                    <div>Date</div>
                    <div className="col-span-2">Description</div>
                    <div>Category</div>
                    <div>Amount</div>
                    <div className="text-right">Actions</div>
                  </div>
                  <div className="divide-y">
                    {currentTransactions.map((transaction) => (
                      <div key={transaction.id} className="grid grid-cols-6 gap-4 p-4 text-sm">
                        <div>{formatDate(transaction.date)}</div>
                        <div className="col-span-2">
                          <div>{transaction.payee}</div>
                          <div className="text-xs text-muted-foreground">{getAccountName(transaction.account)}</div>
                        </div>
                        <div>
                          <span className={getCategoryBadgeClass(transaction.type)}>
                            {getCategoryLabel(transaction.category)}
                          </span>
                        </div>
                        <div className={transaction.type === "income" ? "text-green-600" : ""}>
                          {transaction.type === "income" ? "+" : "-"}
                          {formatCurrency(transaction.amount)}
                        </div>
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="icon" onClick={() => handleEditTransaction(transaction.id)}>
                            <Edit className="h-4 w-4" />
                            <span className="sr-only">Edit</span>
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <Trash2 className="h-4 w-4" />
                                <span className="sr-only">Delete</span>
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  This will permanently delete this transaction. This action cannot be undone.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleDeleteTransaction(transaction.id)}>
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </div>
                    ))}
                    {currentTransactions.length === 0 && (
                      <div className="p-4 text-center text-muted-foreground">No transactions found</div>
                    )}
                  </div>
                </div>
              )}
              <div className="flex items-center justify-between">
                <div className="text-sm text-muted-foreground">
                  Showing {Math.min(filteredTransactions.length, indexOfFirstTransaction + 1)}-
                  {Math.min(indexOfLastTransaction, filteredTransactions.length)} of {filteredTransactions.length}{" "}
                  transactions
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                    disabled={currentPage === 1}
                  >
                    Previous
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                    disabled={currentPage === totalPages || totalPages === 0}
                  >
                    Next
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}

