"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { useFinance } from "@/context/finance-context"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Plus, Search, FileText, Trash2, MoreHorizontal, Send, DollarSign, Copy, Eye } from "lucide-react"
import { formatCurrency, formatDate } from "@/lib/utils"
import { toast } from "@/hooks/use-toast"
import type { InvoiceStatus } from "@/lib/types"
import { ExportButton } from "@/components/export-button"

export default function PurchasesPage() {
  const router = useRouter()
  const { bills, suppliers, deleteBill, updateBill } = useFinance()

  const [filteredBills, setFilteredBills] = useState(bills)
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState<InvoiceStatus | "all">("all")
  const [supplierFilter, setSupplierFilter] = useState("all")
  const [currentPage, setCurrentPage] = useState(1)
  const [billsPerPage] = useState(10)

  // Filter bills when dependencies change
  useEffect(() => {
    let filtered = [...bills]

    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (bill) =>
          bill.billNumber.toLowerCase().includes(query) ||
          suppliers
            .find((s) => s.id === bill.supplierId)
            ?.name.toLowerCase()
            .includes(query),
      )
    }

    // Apply status filter
    if (statusFilter !== "all") {
      filtered = filtered.filter((bill) => bill.status === statusFilter)
    }

    // Apply supplier filter
    if (supplierFilter !== "all") {
      filtered = filtered.filter((bill) => bill.supplierId === supplierFilter)
    }

    // Sort by date (newest first)
    filtered.sort((a, b) => new Date(b.issueDate).getTime() - new Date(a.issueDate).getTime())

    setFilteredBills(filtered)
    setCurrentPage(1) // Reset to first page when filters change
  }, [bills, searchQuery, statusFilter, supplierFilter, suppliers])

  // Get current bills for pagination
  const indexOfLastBill = currentPage * billsPerPage
  const indexOfFirstBill = indexOfLastBill - billsPerPage
  const currentBills = filteredBills.slice(indexOfFirstBill, indexOfLastBill)
  const totalPages = Math.ceil(filteredBills.length / billsPerPage)

  const handleDeleteBill = (id: string) => {
    deleteBill(id)
    toast({
      title: "Bill deleted",
      description: "The bill has been deleted successfully.",
    })
  }

  const handleMarkAsSent = (id: string) => {
    updateBill(id, { status: "sent" })
    toast({
      title: "Bill marked as sent",
      description: "The bill has been marked as sent.",
    })
  }

  const handleMarkAsPaid = (id: string) => {
    const bill = bills.find((b) => b.id === id)
    if (bill) {
      updateBill(id, {
        status: "paid",
        amountPaid: bill.total,
        balance: 0,
      })
      toast({
        title: "Bill marked as paid",
        description: "The bill has been marked as paid.",
      })
    }
  }

  const getStatusBadge = (status: InvoiceStatus) => {
    switch (status) {
      case "draft":
        return <Badge variant="outline">Draft</Badge>
      case "sent":
        return <Badge variant="secondary">Sent</Badge>
      case "paid":
        return <Badge variant="success">Paid</Badge>
      case "overdue":
        return <Badge variant="destructive">Overdue</Badge>
      case "partial":
        return <Badge variant="warning">Partial</Badge>
      case "cancelled":
        return (
          <Badge variant="outline" className="bg-muted">
            Cancelled
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const getSupplierName = (supplierId: string) => {
    return suppliers.find((s) => s.id === supplierId)?.name || "Unknown Supplier"
  }

  const handleCreateBill = () => {
    router.push("/purchases/new")
  }

  // Add these functions to handle the actions:

  const handleViewBill = (id: string) => {
    router.push(`/purchases/${id}`)
  }

  const handleEditBill = (id: string) => {
    router.push(`/purchases/${id}/edit`)
  }

  const handleDuplicateBill = (id: string) => {
    router.push(`/purchases/new?duplicate=${id}`)
  }

  return (
    <div className="flex min-h-screen w-full flex-col">
      <Header />
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-semibold md:text-2xl">Purchases & Bills</h1>
          <div className="flex items-center gap-2">
            <ExportButton
              data={filteredBills}
              columns={[
                { key: "billNumber", label: "Bill #" },
                { key: "supplierId", label: "Supplier", transform: (id) => getSupplierName(id) },
                { key: "issueDate", label: "Issue Date" },
                { key: "dueDate", label: "Due Date" },
                { key: "status", label: "Status" },
                { key: "total", label: "Total" },
                { key: "balance", label: "Balance" },
              ]}
              filename="bills"
            />
            <Button size="sm" onClick={handleCreateBill}>
              <Plus className="mr-2 h-4 w-4" />
              New Bill
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Bills</CardTitle>
            <CardDescription>Manage your purchase bills and track payments.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-4">
              <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      type="search"
                      placeholder="Search bills..."
                      className="pl-8 sm:w-[300px] md:w-[200px] lg:w-[300px]"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
                <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
                  <Select
                    value={statusFilter}
                    onValueChange={(value) => setStatusFilter(value as InvoiceStatus | "all")}
                  >
                    <SelectTrigger className="w-full sm:w-[150px]">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Statuses</SelectItem>
                      <SelectItem value="draft">Draft</SelectItem>
                      <SelectItem value="sent">Sent</SelectItem>
                      <SelectItem value="paid">Paid</SelectItem>
                      <SelectItem value="overdue">Overdue</SelectItem>
                      <SelectItem value="partial">Partial</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={supplierFilter} onValueChange={setSupplierFilter}>
                    <SelectTrigger className="w-full sm:w-[180px]">
                      <SelectValue placeholder="Supplier" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Suppliers</SelectItem>
                      {suppliers.map((supplier) => (
                        <SelectItem key={supplier.id} value={supplier.id}>
                          {supplier.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Bill #</TableHead>
                      <TableHead>Supplier</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Due Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {currentBills.length > 0 ? (
                      currentBills.map((bill) => (
                        <TableRow key={bill.id}>
                          <TableCell className="font-medium">
                            <Link href={`/purchases/${bill.id}`} className="hover:underline">
                              {bill.billNumber}
                            </Link>
                          </TableCell>
                          <TableCell>{getSupplierName(bill.supplierId)}</TableCell>
                          <TableCell>{formatDate(bill.issueDate)}</TableCell>
                          <TableCell>{formatDate(bill.dueDate)}</TableCell>
                          <TableCell>{getStatusBadge(bill.status)}</TableCell>
                          <TableCell className="text-right">{formatCurrency(bill.total)}</TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <MoreHorizontal className="h-4 w-4" />
                                  <span className="sr-only">Actions</span>
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                <DropdownMenuItem onClick={() => handleViewBill(bill.id)}>
                                  <Eye className="mr-2 h-4 w-4" />
                                  View
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleEditBill(bill.id)}>
                                  <FileText className="mr-2 h-4 w-4" />
                                  Edit
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                {bill.status === "draft" && (
                                  <DropdownMenuItem onClick={() => handleMarkAsSent(bill.id)}>
                                    <Send className="mr-2 h-4 w-4" />
                                    Mark as Sent
                                  </DropdownMenuItem>
                                )}
                                {(bill.status === "sent" || bill.status === "overdue") && (
                                  <DropdownMenuItem asChild>
                                    <Link href={`/purchases/${bill.id}/payment`}>
                                      <DollarSign className="mr-2 h-4 w-4" />
                                      Pay Bill
                                    </Link>
                                  </DropdownMenuItem>
                                )}
                                <DropdownMenuItem onClick={() => handleDuplicateBill(bill.id)}>
                                  <Copy className="mr-2 h-4 w-4" />
                                  Duplicate
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <AlertDialog>
                                  <AlertDialogTrigger asChild>
                                    <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                                      <Trash2 className="mr-2 h-4 w-4" />
                                      Delete
                                    </DropdownMenuItem>
                                  </AlertDialogTrigger>
                                  <AlertDialogContent>
                                    <AlertDialogHeader>
                                      <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                      <AlertDialogDescription>
                                        This will permanently delete this bill. This action cannot be undone.
                                      </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                                      <AlertDialogAction onClick={() => handleDeleteBill(bill.id)}>
                                        Delete
                                      </AlertDialogAction>
                                    </AlertDialogFooter>
                                  </AlertDialogContent>
                                </AlertDialog>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={7} className="h-24 text-center">
                          No bills found.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>

              <div className="flex items-center justify-between">
                <div className="text-sm text-muted-foreground">
                  Showing {filteredBills.length > 0 ? indexOfFirstBill + 1 : 0}-
                  {Math.min(indexOfLastBill, filteredBills.length)} of {filteredBills.length} bills
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                    disabled={currentPage === 1}
                  >
                    Previous
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                    disabled={currentPage === totalPages || totalPages === 0}
                  >
                    Next
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}

