"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { useFinance } from "@/context/finance-context"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { DollarSign, Plus, Trash2 } from "lucide-react"
import { v4 as uuidv4 } from "uuid"
import { formatCurrency } from "@/lib/utils"
import { toast } from "@/hooks/use-toast"
import type { InvoiceItem } from "@/lib/types"

export default function NewInvoicePage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { customers, invoices, addInvoice } = useFinance()

  // Form state
  const [customerId, setCustomerId] = useState("")
  const [invoiceNumber, setInvoiceNumber] = useState("")
  const [issueDate, setIssueDate] = useState(new Date().toISOString().split("T")[0])
  const [dueDate, setDueDate] = useState("")
  const [items, setItems] = useState<InvoiceItem[]>([
    {
      id: uuidv4(),
      description: "",
      quantity: 1,
      unitPrice: 0,
      taxRate: 0,
      total: 0,
    },
  ])
  const [notes, setNotes] = useState("")
  const [status, setStatus] = useState("draft")
  const [errors, setErrors] = useState<Record<string, string>>({})

  // Calculate totals
  const subtotal = items.reduce((sum, item) => sum + item.total, 0)
  const taxTotal = items.reduce((sum, item) => sum + (item.total * item.taxRate) / 100, 0)
  const total = subtotal + taxTotal

  // Initialize form with URL parameters or duplicate invoice
  useEffect(() => {
    // Set default due date (30 days from issue date)
    const defaultDueDate = new Date(issueDate)
    defaultDueDate.setDate(defaultDueDate.getDate() + 30)
    setDueDate(defaultDueDate.toISOString().split("T")[0])

    // Generate next invoice number
    const lastInvoice = [...invoices].sort((a, b) => {
      const numA = Number.parseInt(a.invoiceNumber.replace(/\D/g, ""))
      const numB = Number.parseInt(b.invoiceNumber.replace(/\D/g, ""))
      return numB - numA
    })[0]

    let nextNumber = 1001
    if (lastInvoice) {
      const lastNumber = Number.parseInt(lastInvoice.invoiceNumber.replace(/\D/g, ""))
      nextNumber = lastNumber + 1
    }
    setInvoiceNumber(`INV-${nextNumber}`)

    // Check for customerId in URL
    const urlCustomerId = searchParams.get("customerId")
    if (urlCustomerId) {
      setCustomerId(urlCustomerId)
    }

    // Check if duplicating an existing invoice
    const duplicateId = searchParams.get("duplicate")
    if (duplicateId) {
      const invoiceToDuplicate = invoices.find((inv) => inv.id === duplicateId)
      if (invoiceToDuplicate) {
        setCustomerId(invoiceToDuplicate.customerId)
        setItems(
          invoiceToDuplicate.items.map((item) => ({
            ...item,
            id: uuidv4(), // Generate new IDs for items
          })),
        )
        setNotes(invoiceToDuplicate.notes || "")
      }
    }
  }, [searchParams, invoices, issueDate])

  // Update item totals when quantity or price changes
  const updateItem = (id: string, field: string, value: string | number) => {
    setItems((prevItems) =>
      prevItems.map((item) => {
        if (item.id === id) {
          const updatedItem = { ...item, [field]: value }

          // Recalculate total if quantity or unitPrice changed
          if (field === "quantity" || field === "unitPrice") {
            const quantity = field === "quantity" ? Number(value) : item.quantity
            const unitPrice = field === "unitPrice" ? Number(value) : item.unitPrice
            updatedItem.total = quantity * unitPrice
          }

          return updatedItem
        }
        return item
      }),
    )
  }

  // Add a new item
  const addItem = () => {
    setItems([
      ...items,
      {
        id: uuidv4(),
        description: "",
        quantity: 1,
        unitPrice: 0,
        taxRate: 0,
        total: 0,
      },
    ])
  }

  // Remove an item
  const removeItem = (id: string) => {
    if (items.length > 1) {
      setItems(items.filter((item) => item.id !== id))
    } else {
      toast({
        title: "Cannot remove item",
        description: "Invoice must have at least one item.",
        variant: "destructive",
      })
    }
  }

  // Form validation
  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!customerId) {
      newErrors.customerId = "Please select a customer"
    }

    if (!invoiceNumber.trim()) {
      newErrors.invoiceNumber = "Invoice number is required"
    }

    if (!issueDate) {
      newErrors.issueDate = "Issue date is required"
    }

    if (!dueDate) {
      newErrors.dueDate = "Due date is required"
    }

    // Validate items
    let hasItemErrors = false
    items.forEach((item, index) => {
      if (!item.description.trim()) {
        newErrors[`item_${index}_description`] = "Description is required"
        hasItemErrors = true
      }

      if (item.quantity <= 0) {
        newErrors[`item_${index}_quantity`] = "Quantity must be greater than 0"
        hasItemErrors = true
      }

      if (item.unitPrice < 0) {
        newErrors[`item_${index}_unitPrice`] = "Price cannot be negative"
        hasItemErrors = true
      }
    })

    if (hasItemErrors) {
      newErrors.items = "Please fix the errors in your invoice items"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      toast({
        title: "Validation Error",
        description: "Please fix the errors in the form.",
        variant: "destructive",
      })
      return
    }

    addInvoice({
      customerId,
      invoiceNumber,
      issueDate,
      dueDate,
      items,
      subtotal,
      taxTotal,
      total,
      amountPaid: 0,
      balance: total,
      status: status as any,
      notes,
    })

    toast({
      title: "Invoice created",
      description: "Your invoice has been created successfully.",
    })

    router.push("/sales")
  }

  return (
    <div className="flex min-h-screen w-full flex-col">
      <Header />
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-semibold md:text-2xl">New Invoice</h1>
          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={() => router.back()}>
              Cancel
            </Button>
            <Button onClick={handleSubmit}>Save Invoice</Button>
          </div>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 md:grid-cols-2">
            <Card className="md:col-span-1">
              <CardHeader>
                <CardTitle>Customer Information</CardTitle>
                <CardDescription>Select a customer for this invoice.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="customerId">Customer</Label>
                  <Select value={customerId} onValueChange={setCustomerId}>
                    <SelectTrigger id="customerId">
                      <SelectValue placeholder="Select a customer" />
                    </SelectTrigger>
                    <SelectContent>
                      {customers.map((customer) => (
                        <SelectItem key={customer.id} value={customer.id}>
                          {customer.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.customerId && <p className="text-sm text-red-500">{errors.customerId}</p>}
                </div>
              </CardContent>
            </Card>

            <Card className="md:col-span-1">
              <CardHeader>
                <CardTitle>Invoice Details</CardTitle>
                <CardDescription>Enter the invoice details.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="invoiceNumber">Invoice Number</Label>
                  <Input id="invoiceNumber" value={invoiceNumber} onChange={(e) => setInvoiceNumber(e.target.value)} />
                  {errors.invoiceNumber && <p className="text-sm text-red-500">{errors.invoiceNumber}</p>}
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="issueDate">Issue Date</Label>
                    <Input
                      id="issueDate"
                      type="date"
                      value={issueDate}
                      onChange={(e) => setIssueDate(e.target.value)}
                    />
                    {errors.issueDate && <p className="text-sm text-red-500">{errors.issueDate}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="dueDate">Due Date</Label>
                    <Input id="dueDate" type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
                    {errors.dueDate && <p className="text-sm text-red-500">{errors.dueDate}</p>}
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select value={status} onValueChange={setStatus}>
                    <SelectTrigger id="status">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">Draft</SelectItem>
                      <SelectItem value="sent">Sent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Invoice Items</CardTitle>
                <CardDescription>Add items to your invoice.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="rounded-md border">
                  <div className="grid grid-cols-12 gap-2 border-b p-4 font-medium">
                    <div className="col-span-5">Description</div>
                    <div className="col-span-2">Quantity</div>
                    <div className="col-span-2">Unit Price</div>
                    <div className="col-span-2">Tax (%)</div>
                    <div className="col-span-1"></div>
                  </div>
                  <div className="divide-y">
                    {items.map((item, index) => (
                      <div key={item.id} className="grid grid-cols-12 gap-2 p-4">
                        <div className="col-span-5">
                          <Input
                            placeholder="Item description"
                            value={item.description}
                            onChange={(e) => updateItem(item.id, "description", e.target.value)}
                          />
                          {errors[`item_${index}_description`] && (
                            <p className="text-sm text-red-500">{errors[`item_${index}_description`]}</p>
                          )}
                        </div>
                        <div className="col-span-2">
                          <Input
                            type="number"
                            min="1"
                            step="1"
                            value={item.quantity}
                            onChange={(e) => updateItem(item.id, "quantity", Number(e.target.value))}
                          />
                          {errors[`item_${index}_quantity`] && (
                            <p className="text-sm text-red-500">{errors[`item_${index}_quantity`]}</p>
                          )}
                        </div>
                        <div className="col-span-2">
                          <div className="relative">
                            <DollarSign className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                            <Input
                              type="number"
                              min="0"
                              step="0.01"
                              className="pl-7"
                              value={item.unitPrice}
                              onChange={(e) => updateItem(item.id, "unitPrice", Number(e.target.value))}
                            />
                          </div>
                          {errors[`item_${index}_unitPrice`] && (
                            <p className="text-sm text-red-500">{errors[`item_${index}_unitPrice`]}</p>
                          )}
                        </div>
                        <div className="col-span-2">
                          <Input
                            type="number"
                            min="0"
                            max="100"
                            step="0.1"
                            value={item.taxRate}
                            onChange={(e) => updateItem(item.id, "taxRate", Number(e.target.value))}
                          />
                        </div>
                        <div className="col-span-1 flex items-center justify-end">
                          <Button type="button" variant="ghost" size="icon" onClick={() => removeItem(item.id)}>
                            <Trash2 className="h-4 w-4" />
                            <span className="sr-only">Remove item</span>
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="p-4">
                    <Button type="button" variant="outline" size="sm" onClick={addItem}>
                      <Plus className="mr-2 h-4 w-4" />
                      Add Item
                    </Button>
                  </div>
                </div>
                {errors.items && <p className="text-sm text-red-500">{errors.items}</p>}

                <div className="flex justify-end">
                  <div className="w-full max-w-xs space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Subtotal:</span>
                      <span>{formatCurrency(subtotal)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Tax:</span>
                      <span>{formatCurrency(taxTotal)}</span>
                    </div>
                    <div className="flex justify-between border-t pt-2 font-medium">
                      <span>Total:</span>
                      <span>{formatCurrency(total)}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Additional Information</CardTitle>
                <CardDescription>Add notes or payment instructions.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Label htmlFor="notes">Notes</Label>
                  <Textarea
                    id="notes"
                    placeholder="Add any additional notes or payment instructions"
                    rows={4}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                  />
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button type="button" variant="outline" onClick={() => router.back()}>
                  Cancel
                </Button>
                <Button type="submit">Save Invoice</Button>
              </CardFooter>
            </Card>
          </div>
        </form>
      </main>
    </div>
  )
}

