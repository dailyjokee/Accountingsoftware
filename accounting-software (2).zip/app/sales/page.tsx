"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { useFinance } from "@/context/finance-context"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Plus, Search, FileText, Trash2, MoreHorizontal, Send, DollarSign, Copy, Eye } from "lucide-react"
import { formatCurrency, formatDate } from "@/lib/utils"
import { toast } from "@/hooks/use-toast"
import type { InvoiceStatus } from "@/lib/types"

// Add import for ExportButton
import { ExportButton } from "@/components/export-button"

export default function SalesPage() {
  const router = useRouter()
  const { invoices, customers, deleteInvoice, updateInvoice } = useFinance()

  const [filteredInvoices, setFilteredInvoices] = useState(invoices)
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState<InvoiceStatus | "all">("all")
  const [customerFilter, setCustomerFilter] = useState("all")
  const [currentPage, setCurrentPage] = useState(1)
  const [invoicesPerPage] = useState(10)

  // Filter invoices when dependencies change
  useEffect(() => {
    let filtered = [...invoices]

    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (invoice) =>
          invoice.invoiceNumber.toLowerCase().includes(query) ||
          customers
            .find((c) => c.id === invoice.customerId)
            ?.name.toLowerCase()
            .includes(query),
      )
    }

    // Apply status filter
    if (statusFilter !== "all") {
      filtered = filtered.filter((invoice) => invoice.status === statusFilter)
    }

    // Apply customer filter
    if (customerFilter !== "all") {
      filtered = filtered.filter((invoice) => invoice.customerId === customerFilter)
    }

    // Sort by date (newest first)
    filtered.sort((a, b) => new Date(b.issueDate).getTime() - new Date(a.issueDate).getTime())

    setFilteredInvoices(filtered)
    setCurrentPage(1) // Reset to first page when filters change
  }, [invoices, searchQuery, statusFilter, customerFilter, customers])

  // Get current invoices for pagination
  const indexOfLastInvoice = currentPage * invoicesPerPage
  const indexOfFirstInvoice = indexOfLastInvoice - invoicesPerPage
  const currentInvoices = filteredInvoices.slice(indexOfFirstInvoice, indexOfLastInvoice)
  const totalPages = Math.ceil(filteredInvoices.length / invoicesPerPage)

  const handleDeleteInvoice = (id: string) => {
    deleteInvoice(id)
    toast({
      title: "Invoice deleted",
      description: "The invoice has been deleted successfully.",
    })
  }

  const handleMarkAsSent = (id: string) => {
    updateInvoice(id, { status: "sent" })
    toast({
      title: "Invoice marked as sent",
      description: "The invoice has been marked as sent.",
    })
  }

  const handleMarkAsPaid = (id: string) => {
    const invoice = invoices.find((i) => i.id === id)
    if (invoice) {
      updateInvoice(id, {
        status: "paid",
        amountPaid: invoice.total,
        balance: 0,
      })
      toast({
        title: "Invoice marked as paid",
        description: "The invoice has been marked as paid.",
      })
    }
  }

  const getStatusBadge = (status: InvoiceStatus) => {
    switch (status) {
      case "draft":
        return <Badge variant="outline">Draft</Badge>
      case "sent":
        return <Badge variant="secondary">Sent</Badge>
      case "paid":
        return <Badge variant="success">Paid</Badge>
      case "overdue":
        return <Badge variant="destructive">Overdue</Badge>
      case "partial":
        return <Badge variant="warning">Partial</Badge>
      case "cancelled":
        return (
          <Badge variant="outline" className="bg-muted">
            Cancelled
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const getCustomerName = (customerId: string) => {
    return customers.find((c) => c.id === customerId)?.name || "Unknown Customer"
  }

  const handleCreateInvoice = () => {
    router.push("/sales/new")
  }

  // Add these functions to handle the actions:

  const handleViewInvoice = (id: string) => {
    router.push(`/sales/${id}`)
  }

  const handleEditInvoice = (id: string) => {
    router.push(`/sales/${id}/edit`)
  }

  const handleDuplicateInvoice = (id: string) => {
    router.push(`/sales/new?duplicate=${id}`)
  }

  return (
    <div className="flex min-h-screen w-full flex-col">
      <Header />
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-semibold md:text-2xl">Sales & Invoices</h1>
          {/* Replace the Export button in the header section with: */}
          <div className="flex items-center gap-2">
            <ExportButton
              data={filteredInvoices}
              columns={[
                { key: "invoiceNumber", label: "Invoice #" },
                { key: "customerId", label: "Customer", transform: (id) => getCustomerName(id) },
                { key: "issueDate", label: "Issue Date" },
                { key: "dueDate", label: "Due Date" },
                { key: "status", label: "Status" },
                { key: "total", label: "Total" },
                { key: "balance", label: "Balance" },
              ]}
              filename="invoices"
            />
            <Button size="sm" onClick={handleCreateInvoice}>
              <Plus className="mr-2 h-4 w-4" />
              New Invoice
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Invoices</CardTitle>
            <CardDescription>Manage your sales invoices and track payments.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-4">
              <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      type="search"
                      placeholder="Search invoices..."
                      className="pl-8 sm:w-[300px] md:w-[200px] lg:w-[300px]"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
                <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
                  <Select
                    value={statusFilter}
                    onValueChange={(value) => setStatusFilter(value as InvoiceStatus | "all")}
                  >
                    <SelectTrigger className="w-full sm:w-[150px]">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Statuses</SelectItem>
                      <SelectItem value="draft">Draft</SelectItem>
                      <SelectItem value="sent">Sent</SelectItem>
                      <SelectItem value="paid">Paid</SelectItem>
                      <SelectItem value="overdue">Overdue</SelectItem>
                      <SelectItem value="partial">Partial</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={customerFilter} onValueChange={setCustomerFilter}>
                    <SelectTrigger className="w-full sm:w-[180px]">
                      <SelectValue placeholder="Customer" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Customers</SelectItem>
                      {customers.map((customer) => (
                        <SelectItem key={customer.id} value={customer.id}>
                          {customer.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Invoice #</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Due Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {currentInvoices.length > 0 ? (
                      currentInvoices.map((invoice) => (
                        <TableRow key={invoice.id}>
                          <TableCell className="font-medium">
                            <Link href={`/sales/${invoice.id}`} className="hover:underline">
                              {invoice.invoiceNumber}
                            </Link>
                          </TableCell>
                          <TableCell>{getCustomerName(invoice.customerId)}</TableCell>
                          <TableCell>{formatDate(invoice.issueDate)}</TableCell>
                          <TableCell>{formatDate(invoice.dueDate)}</TableCell>
                          <TableCell>{getStatusBadge(invoice.status)}</TableCell>
                          <TableCell className="text-right">{formatCurrency(invoice.total)}</TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <MoreHorizontal className="h-4 w-4" />
                                  <span className="sr-only">Actions</span>
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                <DropdownMenuItem onClick={() => handleViewInvoice(invoice.id)}>
                                  <Eye className="mr-2 h-4 w-4" />
                                  View
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleEditInvoice(invoice.id)}>
                                  <FileText className="mr-2 h-4 w-4" />
                                  Edit
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                {invoice.status === "draft" && (
                                  <DropdownMenuItem onClick={() => handleMarkAsSent(invoice.id)}>
                                    <Send className="mr-2 h-4 w-4" />
                                    Mark as Sent
                                  </DropdownMenuItem>
                                )}
                                {(invoice.status === "sent" || invoice.status === "overdue") && (
                                  <DropdownMenuItem asChild>
                                    <Link href={`/sales/${invoice.id}/payment`}>
                                      <DollarSign className="mr-2 h-4 w-4" />
                                      Record Payment
                                    </Link>
                                  </DropdownMenuItem>
                                )}
                                <DropdownMenuItem onClick={() => handleDuplicateInvoice(invoice.id)}>
                                  <Copy className="mr-2 h-4 w-4" />
                                  Duplicate
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <AlertDialog>
                                  <AlertDialogTrigger asChild>
                                    <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                                      <Trash2 className="mr-2 h-4 w-4" />
                                      Delete
                                    </DropdownMenuItem>
                                  </AlertDialogTrigger>
                                  <AlertDialogContent>
                                    <AlertDialogHeader>
                                      <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                      <AlertDialogDescription>
                                        This will permanently delete this invoice. This action cannot be undone.
                                      </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                                      <AlertDialogAction onClick={() => handleDeleteInvoice(invoice.id)}>
                                        Delete
                                      </AlertDialogAction>
                                    </AlertDialogFooter>
                                  </AlertDialogContent>
                                </AlertDialog>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={7} className="h-24 text-center">
                          No invoices found.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>

              <div className="flex items-center justify-between">
                <div className="text-sm text-muted-foreground">
                  Showing {filteredInvoices.length > 0 ? indexOfFirstInvoice + 1 : 0}-
                  {Math.min(indexOfLastInvoice, filteredInvoices.length)} of {filteredInvoices.length} invoices
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                    disabled={currentPage === 1}
                  >
                    Previous
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                    disabled={currentPage === totalPages || totalPages === 0}
                  >
                    Next
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}

