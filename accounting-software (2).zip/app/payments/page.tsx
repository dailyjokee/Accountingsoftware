"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useFinance } from "@/context/finance-context"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Search, FileText, ShoppingCart, BarChart3 } from "lucide-react"
import { formatCurrency, formatDate } from "@/lib/utils"
import { ExportButton } from "@/components/export-button"

export default function PaymentsPage() {
  const { payments, invoices, bills, customers, suppliers } = useFinance()
  const [filteredPayments, setFilteredPayments] = useState(payments)
  const [searchQuery, setSearchQuery] = useState("")
  const [typeFilter, setTypeFilter] = useState("all")
  const [currentPage, setCurrentPage] = useState(1)
  const [paymentsPerPage] = useState(10)

  useEffect(() => {
    let filtered = [...payments]

    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter((payment) => {
        const relatedEntity =
          payment.relatedType === "invoice"
            ? invoices.find((i) => i.id === payment.relatedId)
            : bills.find((b) => b.id === payment.relatedId)

        const entityNumber =
          payment.relatedType === "invoice"
            ? relatedEntity
              ? (relatedEntity as (typeof invoices)[0]).invoiceNumber
              : ""
            : relatedEntity
              ? (relatedEntity as (typeof bills)[0]).billNumber
              : ""

        const entityName =
          payment.relatedType === "invoice"
            ? relatedEntity
              ? customers.find((c) => c.id === (relatedEntity as (typeof invoices)[0]).customerId)?.name || ""
              : ""
            : relatedEntity
              ? suppliers.find((s) => s.id === (relatedEntity as (typeof bills)[0]).supplierId)?.name || ""
              : ""

        return (
          entityNumber.toLowerCase().includes(query) ||
          entityName.toLowerCase().includes(query) ||
          payment.method.toLowerCase().includes(query)
        )
      })
    }

    // Apply type filter
    if (typeFilter !== "all") {
      filtered = filtered.filter((payment) => payment.relatedType === typeFilter)
    }

    // Sort by date (newest first)
    filtered.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())

    setFilteredPayments(filtered)
    setCurrentPage(1) // Reset to first page when filters change
  }, [payments, searchQuery, typeFilter, invoices, bills, customers, suppliers])

  // Get current payments for pagination
  const indexOfLastPayment = currentPage * paymentsPerPage
  const indexOfFirstPayment = indexOfLastPayment - paymentsPerPage
  const currentPayments = filteredPayments.slice(indexOfFirstPayment, indexOfLastPayment)
  const totalPages = Math.ceil(filteredPayments.length / paymentsPerPage)

  const getRelatedEntityInfo = (payment: (typeof payments)[0]) => {
    if (payment.relatedType === "invoice") {
      const invoice = invoices.find((i) => i.id === payment.relatedId)
      if (!invoice) return { number: "Unknown", entity: "Unknown" }

      const customer = customers.find((c) => c.id === invoice.customerId)
      return {
        number: invoice.invoiceNumber,
        entity: customer?.name || "Unknown Customer",
        url: `/sales/${payment.relatedId}`,
      }
    } else {
      const bill = bills.find((b) => b.id === payment.relatedId)
      if (!bill) return { number: "Unknown", entity: "Unknown" }

      const supplier = suppliers.find((s) => s.id === bill.supplierId)
      return {
        number: bill.billNumber,
        entity: supplier?.name || "Unknown Supplier",
        url: `/purchases/${payment.relatedId}`,
      }
    }
  }

  return (
    <div className="flex min-h-screen w-full flex-col">
      <Header />
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-semibold md:text-2xl">Payments</h1>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" asChild>
              <Link href="/payments/dashboard">
                <BarChart3 className="mr-2 h-4 w-4" />
                Dashboard
              </Link>
            </Button>
            <ExportButton
              data={filteredPayments}
              columns={[
                { key: "date", label: "Date" },
                { key: "relatedType", label: "Type" },
                { key: "relatedId", label: "Reference" },
                { key: "method", label: "Method" },
                { key: "amount", label: "Amount" },
              ]}
              filename="payments"
            />
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Payment History</CardTitle>
            <CardDescription>View all payments made and received.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-4">
              <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      type="search"
                      placeholder="Search payments..."
                      className="pl-8 sm:w-[300px] md:w-[200px] lg:w-[300px]"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
                <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
                  <Select value={typeFilter} onValueChange={setTypeFilter}>
                    <SelectTrigger className="w-full sm:w-[150px]">
                      <SelectValue placeholder="Type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="invoice">Invoices</SelectItem>
                      <SelectItem value="bill">Bills</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Reference</TableHead>
                      <TableHead>Customer/Supplier</TableHead>
                      <TableHead>Method</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {currentPayments.map((payment) => {
                      const relatedInfo = getRelatedEntityInfo(payment)
                      return (
                        <TableRow key={payment.id}>
                          <TableCell>{formatDate(payment.date)}</TableCell>
                          <TableCell>
                            {payment.relatedType === "invoice" ? (
                              <div className="flex items-center">
                                <FileText className="mr-2 h-4 w-4 text-blue-500" />
                                <span>Invoice Payment</span>
                              </div>
                            ) : (
                              <div className="flex items-center">
                                <ShoppingCart className="mr-2 h-4 w-4 text-green-500" />
                                <span>Bill Payment</span>
                              </div>
                            )}
                          </TableCell>
                          <TableCell>
                            <Link href={relatedInfo.url} className="hover:underline">
                              {relatedInfo.number}
                            </Link>
                          </TableCell>
                          <TableCell>{relatedInfo.entity}</TableCell>
                          <TableCell>
                            {payment.method
                              .split("_")
                              .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
                              .join(" ")}
                          </TableCell>
                          <TableCell className="text-right">
                            <span className={payment.relatedType === "invoice" ? "text-green-600" : "text-red-600"}>
                              {payment.relatedType === "invoice" ? "+" : "-"}
                              {formatCurrency(payment.amount)}
                            </span>
                          </TableCell>
                        </TableRow>
                      )
                    })}

                    {currentPayments.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={6} className="h-24 text-center">
                          No payments found.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>

              <div className="flex items-center justify-between">
                <div className="text-sm text-muted-foreground">
                  Showing {Math.min(filteredPayments.length, indexOfFirstPayment + 1)}-
                  {Math.min(indexOfLastPayment, filteredPayments.length)} of {filteredPayments.length} payments
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                    disabled={currentPage === 1}
                  >
                    Previous
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                    disabled={currentPage === totalPages || totalPages === 0}
                  >
                    Next
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}

