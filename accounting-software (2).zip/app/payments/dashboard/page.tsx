"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useFinance } from "@/context/finance-context"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, ArrowRight, ArrowUp, ArrowDown } from "lucide-react"
import { formatCurrency } from "@/lib/utils"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

export default function PaymentsDashboardPage() {
  const { payments, invoices, bills } = useFinance()
  const [isClient, setIsClient] = useState(false)
  const [period, setPeriod] = useState("month")
  const [paymentStats, setPaymentStats] = useState({
    totalReceived: 0,
    totalPaid: 0,
    netCashFlow: 0,
    receivedByMethod: {} as Record<string, number>,
    paidByMethod: {} as Record<string, number>,
    monthlyData: [] as { name: string; received: number; paid: number }[],
  })

  // Fix for hydration issues
  useEffect(() => {
    setIsClient(true)
  }, [])

  useEffect(() => {
    // Calculate payment statistics
    const received = payments.filter((p) => p.relatedType === "invoice").reduce((sum, p) => sum + p.amount, 0)
    const paid = payments.filter((p) => p.relatedType === "bill").reduce((sum, p) => sum + p.amount, 0)

    // Calculate payments by method
    const receivedByMethod: Record<string, number> = {}
    const paidByMethod: Record<string, number> = {}

    payments.forEach((payment) => {
      const method = payment.method
      if (payment.relatedType === "invoice") {
        receivedByMethod[method] = (receivedByMethod[method] || 0) + payment.amount
      } else {
        paidByMethod[method] = (paidByMethod[method] || 0) + payment.amount
      }
    })

    // Calculate monthly data
    const monthlyData: Record<string, { received: number; paid: number }> = {}

    // Get date range based on period
    const now = new Date()
    const startDate = new Date()
    if (period === "month") {
      startDate.setMonth(now.getMonth() - 1)
    } else if (period === "quarter") {
      startDate.setMonth(now.getMonth() - 3)
    } else if (period === "year") {
      startDate.setFullYear(now.getFullYear() - 1)
    }

    // Filter payments within the date range
    const filteredPayments = payments.filter((p) => new Date(p.date) >= startDate)

    // Group by month
    filteredPayments.forEach((payment) => {
      const date = new Date(payment.date)
      const monthYear = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`

      if (!monthlyData[monthYear]) {
        monthlyData[monthYear] = { received: 0, paid: 0 }
      }

      if (payment.relatedType === "invoice") {
        monthlyData[monthYear].received += payment.amount
      } else {
        monthlyData[monthYear].paid += payment.amount
      }
    })

    // Convert to array and sort by date
    const monthlyDataArray = Object.entries(monthlyData)
      .map(([month, data]) => ({
        name: formatMonthYear(month),
        received: data.received,
        paid: data.paid,
      }))
      .sort((a, b) => a.name.localeCompare(b.name))

    setPaymentStats({
      totalReceived: received,
      totalPaid: paid,
      netCashFlow: received - paid,
      receivedByMethod,
      paidByMethod,
      monthlyData: monthlyDataArray,
    })
  }, [payments, period])

  const formatMonthYear = (monthYear: string) => {
    const [year, month] = monthYear.split("-")
    const date = new Date(Number.parseInt(year), Number.parseInt(month) - 1)
    return date.toLocaleDateString("en-US", { month: "short", year: "numeric" })
  }

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8", "#82CA9D"]

  const formatMethodName = (method: string) => {
    return method
      .split("_")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ")
  }

  const receivedByMethodData = Object.entries(paymentStats.receivedByMethod).map(([method, amount], index) => ({
    name: formatMethodName(method),
    value: amount,
  }))

  const paidByMethodData = Object.entries(paymentStats.paidByMethod).map(([method, amount], index) => ({
    name: formatMethodName(method),
    value: amount,
  }))

  return (
    <div className="flex min-h-screen w-full flex-col">
      <Header />
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" asChild>
              <Link href="/payments">
                <ArrowLeft className="h-4 w-4" />
                <span className="sr-only">Back</span>
              </Link>
            </Button>
            <h1 className="text-lg font-semibold md:text-2xl">Payment Dashboard</h1>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPeriod("month")}
              className={period === "month" ? "bg-primary text-primary-foreground" : ""}
            >
              Month
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPeriod("quarter")}
              className={period === "quarter" ? "bg-primary text-primary-foreground" : ""}
            >
              Quarter
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPeriod("year")}
              className={period === "year" ? "bg-primary text-primary-foreground" : ""}
            >
              Year
            </Button>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Received</CardTitle>
              <ArrowDown className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatCurrency(paymentStats.totalReceived)}</div>
              <p className="text-xs text-muted-foreground">From {invoices.length} invoices</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Paid</CardTitle>
              <ArrowUp className="h-4 w-4 text-red-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatCurrency(paymentStats.totalPaid)}</div>
              <p className="text-xs text-muted-foreground">From {bills.length} bills</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Net Cash Flow</CardTitle>
              {paymentStats.netCashFlow >= 0 ? (
                <ArrowRight className="h-4 w-4 text-green-500" />
              ) : (
                <ArrowLeft className="h-4 w-4 text-red-500" />
              )}
            </CardHeader>
            <CardContent>
              <div
                className={`text-2xl font-bold ${paymentStats.netCashFlow >= 0 ? "text-green-600" : "text-red-600"}`}
              >
                {formatCurrency(Math.abs(paymentStats.netCashFlow))}
              </div>
              <p className="text-xs text-muted-foreground">
                {paymentStats.netCashFlow >= 0 ? "Positive" : "Negative"} cash flow
              </p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="received">Received</TabsTrigger>
            <TabsTrigger value="paid">Paid</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Payment Flow</CardTitle>
                <CardDescription>Overview of payments received vs. paid over time</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                {isClient && (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={paymentStats.monthlyData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip formatter={(value) => formatCurrency(value as number)} />
                      <Legend />
                      <Bar dataKey="received" name="Received" fill="#4ade80" />
                      <Bar dataKey="paid" name="Paid" fill="#f87171" />
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="received" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Payments Received by Method</CardTitle>
                <CardDescription>Breakdown of payment methods for received payments</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                {isClient && receivedByMethodData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={receivedByMethodData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {receivedByMethodData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => formatCurrency(value as number)} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex h-full items-center justify-center">
                    <p className="text-muted-foreground">No payment data available</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="paid" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Payments Paid by Method</CardTitle>
                <CardDescription>Breakdown of payment methods for paid bills</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                {isClient && paidByMethodData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={paidByMethodData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {paidByMethodData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => formatCurrency(value as number)} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex h-full items-center justify-center">
                    <p className="text-muted-foreground">No payment data available</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

