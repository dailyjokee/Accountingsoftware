"use client"

import { useState, useRef, useCallback } from "react"
import { useFinance } from "@/context/finance-context"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Textarea } from "@/components/ui/textarea"
import { Plus, Pencil, Trash2, Search, FileText } from "lucide-react"
import { formatCurrency } from "@/lib/utils"
import { toast } from "@/hooks/use-toast"
import { ExportButton } from "@/components/export-button"
import { useRouter } from "next/navigation"

export default function CustomersAndSuppliersPage() {
  const {
    customers,
    addCustomer,
    updateCustomer,
    deleteCustomer,
    suppliers,
    addSupplier,
    updateSupplier,
    deleteSupplier,
    invoices,
    bills,
  } = useFinance()

  const router = useRouter()

  // Use a ref to track tab changes without causing re-renders
  const tabRef = useRef("customers")
  const [activeTab, setActiveTab] = useState("customers")
  const [searchQuery, setSearchQuery] = useState("")

  // Customer state
  const [isAddCustomerDialogOpen, setIsAddCustomerDialogOpen] = useState(false)
  const [isEditCustomerDialogOpen, setIsEditCustomerDialogOpen] = useState(false)
  const [editCustomerId, setEditCustomerId] = useState("")
  const [customerName, setCustomerName] = useState("")
  const [customerEmail, setCustomerEmail] = useState("")
  const [customerPhone, setCustomerPhone] = useState("")
  const [customerAddress, setCustomerAddress] = useState("")
  const [customerNotes, setCustomerNotes] = useState("")
  const [customerErrors, setCustomerErrors] = useState<Record<string, string>>({})

  // Supplier state
  const [isAddSupplierDialogOpen, setIsAddSupplierDialogOpen] = useState(false)
  const [isEditSupplierDialogOpen, setIsEditSupplierDialogOpen] = useState(false)
  const [editSupplierId, setEditSupplierId] = useState("")
  const [supplierName, setSupplierName] = useState("")
  const [supplierEmail, setSupplierEmail] = useState("")
  const [supplierPhone, setSupplierPhone] = useState("")
  const [supplierAddress, setSupplierAddress] = useState("")
  const [supplierNotes, setSupplierNotes] = useState("")
  const [supplierErrors, setSupplierErrors] = useState<Record<string, string>>({})

  // Memoize filter functions to prevent recreation on every render
  const getFilteredCustomers = useCallback(() => {
    return customers.filter(
      (customer) =>
        customer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        customer.email.toLowerCase().includes(searchQuery.toLowerCase()),
    )
  }, [customers, searchQuery])

  const getFilteredSuppliers = useCallback(() => {
    return suppliers.filter(
      (supplier) =>
        supplier.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        supplier.email.toLowerCase().includes(searchQuery.toLowerCase()),
    )
  }, [suppliers, searchQuery])

  // Filter customers/suppliers based on search query
  const filteredCustomers = getFilteredCustomers()
  const filteredSuppliers = getFilteredSuppliers()

  // Handle tab change without triggering re-renders
  const handleTabChange = (value: string) => {
    if (value !== tabRef.current) {
      tabRef.current = value
      setActiveTab(value)
    }
  }

  // Customer form validation
  const validateCustomerForm = () => {
    const errors: Record<string, string> = {}

    if (!customerName.trim()) {
      errors.name = "Name is required"
    }

    if (!customerEmail.trim()) {
      errors.email = "Email is required"
    } else if (!/\S+@\S+\.\S+/.test(customerEmail)) {
      errors.email = "Email is invalid"
    }

    setCustomerErrors(errors)
    return Object.keys(errors).length === 0
  }

  // Supplier form validation
  const validateSupplierForm = () => {
    const errors: Record<string, string> = {}

    if (!supplierName.trim()) {
      errors.name = "Name is required"
    }

    if (!supplierEmail.trim()) {
      errors.email = "Email is required"
    } else if (!/\S+@\S+\.\S+/.test(supplierEmail)) {
      errors.email = "Email is invalid"
    }

    setSupplierErrors(errors)
    return Object.keys(errors).length === 0
  }

  // Customer handlers
  const handleAddCustomer = () => {
    if (!validateCustomerForm()) return

    addCustomer({
      name: customerName,
      email: customerEmail,
      phone: customerPhone,
      address: customerAddress,
      notes: customerNotes,
    })

    toast({
      title: "Customer added",
      description: "The customer has been added successfully.",
    })

    setIsAddCustomerDialogOpen(false)
    resetCustomerForm()
  }

  const openEditCustomerDialog = (id: string) => {
    const customer = customers.find((c) => c.id === id)
    if (customer) {
      setEditCustomerId(id)
      setCustomerName(customer.name)
      setCustomerEmail(customer.email)
      setCustomerPhone(customer.phone || "")
      setCustomerAddress(customer.address || "")
      setCustomerNotes(customer.notes || "")
      setIsEditCustomerDialogOpen(true)
    }
  }

  const handleEditCustomer = () => {
    if (!validateCustomerForm()) return

    updateCustomer(editCustomerId, {
      name: customerName,
      email: customerEmail,
      phone: customerPhone,
      address: customerAddress,
      notes: customerNotes,
    })

    toast({
      title: "Customer updated",
      description: "The customer has been updated successfully.",
    })

    setIsEditCustomerDialogOpen(false)
    resetCustomerForm()
  }

  const handleDeleteCustomer = (id: string) => {
    deleteCustomer(id)

    toast({
      title: "Customer deleted",
      description: "The customer has been deleted successfully.",
    })
  }

  const resetCustomerForm = () => {
    setCustomerName("")
    setCustomerEmail("")
    setCustomerPhone("")
    setCustomerAddress("")
    setCustomerNotes("")
    setCustomerErrors({})
  }

  // Supplier handlers
  const handleAddSupplier = () => {
    if (!validateSupplierForm()) return

    addSupplier({
      name: supplierName,
      email: supplierEmail,
      phone: supplierPhone,
      address: supplierAddress,
      notes: supplierNotes,
    })

    toast({
      title: "Supplier added",
      description: "The supplier has been added successfully.",
    })

    setIsAddSupplierDialogOpen(false)
    resetSupplierForm()
  }

  const openEditSupplierDialog = (id: string) => {
    const supplier = suppliers.find((s) => s.id === id)
    if (supplier) {
      setEditSupplierId(id)
      setSupplierName(supplier.name)
      setSupplierEmail(supplier.email)
      setSupplierPhone(supplier.phone || "")
      setSupplierAddress(supplier.address || "")
      setSupplierNotes(supplier.notes || "")
      setIsEditSupplierDialogOpen(true)
    }
  }

  const handleEditSupplier = () => {
    if (!validateSupplierForm()) return

    updateSupplier(editSupplierId, {
      name: supplierName,
      email: supplierEmail,
      phone: supplierPhone,
      address: supplierAddress,
      notes: supplierNotes,
    })

    toast({
      title: "Supplier updated",
      description: "The supplier has been updated successfully.",
    })

    setIsEditSupplierDialogOpen(false)
    resetSupplierForm()
  }

  const handleDeleteSupplier = (id: string) => {
    deleteSupplier(id)

    toast({
      title: "Supplier deleted",
      description: "The supplier has been deleted successfully.",
    })
  }

  const resetSupplierForm = () => {
    setSupplierName("")
    setSupplierEmail("")
    setSupplierPhone("")
    setSupplierAddress("")
    setSupplierNotes("")
    setSupplierErrors({})
  }

  // Get customer/supplier stats - memoize to prevent recalculation on every render
  const getCustomerStats = useCallback(
    (id: string) => {
      const customerInvoices = invoices.filter((invoice) => invoice.customerId === id)
      const totalInvoiced = customerInvoices.reduce((sum, invoice) => sum + invoice.total, 0)
      const totalPaid = customerInvoices.reduce((sum, invoice) => sum + invoice.amountPaid, 0)
      const totalOutstanding = customerInvoices.reduce((sum, invoice) => sum + invoice.balance, 0)

      return {
        invoiceCount: customerInvoices.length,
        totalInvoiced,
        totalPaid,
        totalOutstanding,
      }
    },
    [invoices],
  )

  const getSupplierStats = useCallback(
    (id: string) => {
      const supplierBills = bills.filter((bill) => bill.supplierId === id)
      const totalBilled = supplierBills.reduce((sum, bill) => sum + bill.total, 0)
      const totalPaid = supplierBills.reduce((sum, bill) => sum + bill.amountPaid, 0)
      const totalOutstanding = supplierBills.reduce((sum, bill) => sum + bill.balance, 0)

      return {
        billCount: supplierBills.length,
        totalBilled,
        totalPaid,
        totalOutstanding,
      }
    },
    [bills],
  )

  // Add these functions to handle the actions:
  const handleViewInvoices = (customerId: string) => {
    router.push(`/sales?customerId=${customerId}`)
  }

  const handleCreateInvoice = (customerId: string) => {
    router.push(`/sales/new?customerId=${customerId}`)
  }

  const handleViewBills = (supplierId: string) => {
    router.push(`/purchases?supplierId=${supplierId}`)
  }

  const handleCreateBill = (supplierId: string) => {
    router.push(`/purchases/new?supplierId=${supplierId}`)
  }

  return (
    <div className="flex min-h-screen w-full flex-col">
      <Header />
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-semibold md:text-2xl">Customers & Suppliers</h1>
          <div className="flex items-center gap-2">
            <ExportButton
              data={activeTab === "customers" ? filteredCustomers : filteredSuppliers}
              columns={
                activeTab === "customers"
                  ? [
                      { key: "name", label: "Name" },
                      { key: "email", label: "Email" },
                      { key: "phone", label: "Phone" },
                      { key: "balance", label: "Balance" },
                    ]
                  : [
                      { key: "name", label: "Name" },
                      { key: "email", label: "Email" },
                      { key: "phone", label: "Phone" },
                      { key: "balance", label: "Balance" },
                    ]
              }
              filename={activeTab === "customers" ? "customers" : "suppliers"}
            />
            {activeTab === "customers" ? (
              <Dialog open={isAddCustomerDialogOpen} onOpenChange={setIsAddCustomerDialogOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Customer
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add New Customer</DialogTitle>
                    <DialogDescription>Enter the details for your new customer.</DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid gap-2">
                      <Label htmlFor="name">Name</Label>
                      <Input
                        id="name"
                        placeholder="Customer name"
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                      />
                      {customerErrors.name && <p className="text-sm text-red-500">{customerErrors.name}</p>}
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="customer@example.com"
                        value={customerEmail}
                        onChange={(e) => setCustomerEmail(e.target.value)}
                      />
                      {customerErrors.email && <p className="text-sm text-red-500">{customerErrors.email}</p>}
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="phone">Phone (optional)</Label>
                      <Input
                        id="phone"
                        placeholder="(555) 123-4567"
                        value={customerPhone}
                        onChange={(e) => setCustomerPhone(e.target.value)}
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="address">Address (optional)</Label>
                      <Textarea
                        id="address"
                        placeholder="Customer address"
                        value={customerAddress}
                        onChange={(e) => setCustomerAddress(e.target.value)}
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="notes">Notes (optional)</Label>
                      <Textarea
                        id="notes"
                        placeholder="Additional notes"
                        value={customerNotes}
                        onChange={(e) => setCustomerNotes(e.target.value)}
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsAddCustomerDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleAddCustomer}>Add Customer</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            ) : (
              <Dialog open={isAddSupplierDialogOpen} onOpenChange={setIsAddSupplierDialogOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Supplier
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add New Supplier</DialogTitle>
                    <DialogDescription>Enter the details for your new supplier.</DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid gap-2">
                      <Label htmlFor="name">Name</Label>
                      <Input
                        id="name"
                        placeholder="Supplier name"
                        value={supplierName}
                        onChange={(e) => setSupplierName(e.target.value)}
                      />
                      {supplierErrors.name && <p className="text-sm text-red-500">{supplierErrors.name}</p>}
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="supplier@example.com"
                        value={supplierEmail}
                        onChange={(e) => setSupplierEmail(e.target.value)}
                      />
                      {supplierErrors.email && <p className="text-sm text-red-500">{supplierErrors.email}</p>}
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="phone">Phone (optional)</Label>
                      <Input
                        id="phone"
                        placeholder="(555) 123-4567"
                        value={supplierPhone}
                        onChange={(e) => setSupplierPhone(e.target.value)}
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="address">Address (optional)</Label>
                      <Textarea
                        id="address"
                        placeholder="Supplier address"
                        value={supplierAddress}
                        onChange={(e) => setSupplierAddress(e.target.value)}
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="notes">Notes (optional)</Label>
                      <Textarea
                        id="notes"
                        placeholder="Additional notes"
                        value={supplierNotes}
                        onChange={(e) => setSupplierNotes(e.target.value)}
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsAddSupplierDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleAddSupplier}>Add Supplier</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            )}
          </div>
        </div>

        <div className="flex items-center gap-4 mb-4">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder={`Search ${activeTab}...`}
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        <Tabs defaultValue="customers" className="w-full" value={activeTab} onValueChange={handleTabChange}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="customers">Customers</TabsTrigger>
            <TabsTrigger value="suppliers">Suppliers</TabsTrigger>
          </TabsList>

          <TabsContent value="customers" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {filteredCustomers.map((customer) => {
                const stats = getCustomerStats(customer.id)

                return (
                  <Card key={customer.id}>
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <CardTitle>{customer.name}</CardTitle>
                        <div className="flex gap-2">
                          <Button variant="ghost" size="icon" onClick={() => openEditCustomerDialog(customer.id)}>
                            <Pencil className="h-4 w-4" />
                            <span className="sr-only">Edit</span>
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <Trash2 className="h-4 w-4" />
                                <span className="sr-only">Delete</span>
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  This will permanently delete this customer. This action cannot be undone.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleDeleteCustomer(customer.id)}>
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </div>
                      <CardDescription>
                        <div className="flex flex-col gap-1 mt-1">
                          <span>{customer.email}</span>
                          {customer.phone && <span>{customer.phone}</span>}
                        </div>
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Outstanding:</span>
                          <span className="font-medium">{formatCurrency(customer.balance)}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Invoices:</span>
                          <span className="font-medium">{stats.invoiceCount}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Total Invoiced:</span>
                          <span className="font-medium">{formatCurrency(stats.totalInvoiced)}</span>
                        </div>
                        <div className="mt-4 flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="w-full"
                            onClick={() => handleViewInvoices(customer.id)}
                          >
                            <FileText className="mr-2 h-4 w-4" />
                            Invoices
                          </Button>
                          <Button size="sm" className="w-full" onClick={() => handleCreateInvoice(customer.id)}>
                            <Plus className="mr-2 h-4 w-4" />
                            New Invoice
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}

              {filteredCustomers.length === 0 && (
                <Card className="col-span-full">
                  <CardContent className="flex flex-col items-center justify-center p-6">
                    <p className="mb-4 text-center text-muted-foreground">
                      {searchQuery
                        ? "No customers match your search."
                        : "No customers found. Add your first customer to get started."}
                    </p>
                    <Button onClick={() => setIsAddCustomerDialogOpen(true)}>
                      <Plus className="mr-2 h-4 w-4" />
                      Add Customer
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="suppliers" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {filteredSuppliers.map((supplier) => {
                const stats = getSupplierStats(supplier.id)

                return (
                  <Card key={supplier.id}>
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <CardTitle>{supplier.name}</CardTitle>
                        <div className="flex gap-2">
                          <Button variant="ghost" size="icon" onClick={() => openEditSupplierDialog(supplier.id)}>
                            <Pencil className="h-4 w-4" />
                            <span className="sr-only">Edit</span>
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <Trash2 className="h-4 w-4" />
                                <span className="sr-only">Delete</span>
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  This will permanently delete this supplier. This action cannot be undone.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleDeleteSupplier(supplier.id)}>
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </div>
                      <CardDescription>
                        <div className="flex flex-col gap-1 mt-1">
                          <span>{supplier.email}</span>
                          {supplier.phone && <span>{supplier.phone}</span>}
                        </div>
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Outstanding:</span>
                          <span className="font-medium">{formatCurrency(supplier.balance)}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Bills:</span>
                          <span className="font-medium">{stats.billCount}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Total Billed:</span>
                          <span className="font-medium">{formatCurrency(stats.totalBilled)}</span>
                        </div>
                        <div className="mt-4 flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="w-full"
                            onClick={() => handleViewBills(supplier.id)}
                          >
                            <FileText className="mr-2 h-4 w-4" />
                            Bills
                          </Button>
                          <Button size="sm" className="w-full" onClick={() => handleCreateBill(supplier.id)}>
                            <Plus className="mr-2 h-4 w-4" />
                            New Bill
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}

              {filteredSuppliers.length === 0 && (
                <Card className="col-span-full">
                  <CardContent className="flex flex-col items-center justify-center p-6">
                    <p className="mb-4 text-center text-muted-foreground">
                      {searchQuery
                        ? "No suppliers match your search."
                        : "No suppliers found. Add your first supplier to get started."}
                    </p>
                    <Button onClick={() => setIsAddSupplierDialogOpen(true)}>
                      <Plus className="mr-2 h-4 w-4" />
                      Add Supplier
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {/* Edit Customer Dialog */}
      <Dialog open={isEditCustomerDialogOpen} onOpenChange={setIsEditCustomerDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Customer</DialogTitle>
            <DialogDescription>Update the details for this customer.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-name">Name</Label>
              <Input
                id="edit-name"
                placeholder="Customer name"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
              />
              {customerErrors.name && <p className="text-sm text-red-500">{customerErrors.name}</p>}
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-email">Email</Label>
              <Input
                id="edit-email"
                type="email"
                placeholder="customer@example.com"
                value={customerEmail}
                onChange={(e) => setCustomerEmail(e.target.value)}
              />
              {customerErrors.email && <p className="text-sm text-red-500">{customerErrors.email}</p>}
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-phone">Phone (optional)</Label>
              <Input
                id="edit-phone"
                placeholder="(555) 123-4567"
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-address">Address (optional)</Label>
              <Textarea
                id="edit-address"
                placeholder="Customer address"
                value={customerAddress}
                onChange={(e) => setCustomerAddress(e.target.value)}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-notes">Notes (optional)</Label>
              <Textarea
                id="edit-notes"
                placeholder="Additional notes"
                value={customerNotes}
                onChange={(e) => setCustomerNotes(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditCustomerDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleEditCustomer}>Update Customer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Supplier Dialog */}
      <Dialog open={isEditSupplierDialogOpen} onOpenChange={setIsEditSupplierDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Supplier</DialogTitle>
            <DialogDescription>Update the details for this supplier.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-name">Name</Label>
              <Input
                id="edit-name"
                placeholder="Supplier name"
                value={supplierName}
                onChange={(e) => setSupplierName(e.target.value)}
              />
              {supplierErrors.name && <p className="text-sm text-red-500">{supplierErrors.name}</p>}
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-email">Email</Label>
              <Input
                id="edit-email"
                type="email"
                placeholder="supplier@example.com"
                value={supplierEmail}
                onChange={(e) => setSupplierEmail(e.target.value)}
              />
              {supplierErrors.email && <p className="text-sm text-red-500">{supplierErrors.email}</p>}
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-phone">Phone (optional)</Label>
              <Input
                id="edit-phone"
                placeholder="(555) 123-4567"
                value={supplierPhone}
                onChange={(e) => setSupplierPhone(e.target.value)}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-address">Address (optional)</Label>
              <Textarea
                id="edit-address"
                placeholder="Supplier address"
                value={supplierAddress}
                onChange={(e) => setSupplierAddress(e.target.value)}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-notes">Notes (optional)</Label>
              <Textarea
                id="edit-notes"
                placeholder="Additional notes"
                value={supplierNotes}
                onChange={(e) => setSupplierNotes(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditSupplierDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleEditSupplier}>Update Supplier</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

