"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Users, FileText, ShoppingCart, BarChart3 } from "lucide-react"

export default function FeatureGuide() {
  const [activeTab, setActiveTab] = useState("customers")

  return (
    <div className="flex min-h-screen w-full flex-col">
      <Header />
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-semibold md:text-2xl">Feature Guide</h1>
        </div>

        <Tabs defaultValue="customers" className="w-full" onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="customers">Customers & Suppliers</TabsTrigger>
            <TabsTrigger value="sales">Sales</TabsTrigger>
            <TabsTrigger value="purchases">Purchases</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
          </TabsList>

          {/* Customers & Suppliers Tab */}
          <TabsContent value="customers" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="mr-2 h-5 w-5" />
                  Customers & Suppliers
                </CardTitle>
                <CardDescription>Manage your customers and suppliers information</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="rounded-lg border overflow-hidden">
                  <div className="bg-muted p-4 font-medium">Step 1: Navigate to Customers & Suppliers</div>
                  <div className="p-4 space-y-4">
                    <p>Click on the "Customers & Suppliers" link in the main navigation bar.</p>
                    <div className="flex items-center gap-2 p-2 bg-muted/50 rounded-md">
                      <div className="flex h-10 items-center gap-4 border-b bg-background px-4">
                        <span className="font-semibold">FinanceTrack</span>
                        <span className="text-sm text-muted-foreground underline">Dashboard</span>
                        <span className="text-sm text-muted-foreground underline">Transactions</span>
                        <span className="text-sm text-muted-foreground underline">Reports</span>
                        <span className="text-sm font-medium underline-offset-4 hover:text-foreground hover:underline">
                          Customers & Suppliers
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="rounded-lg border overflow-hidden">
                  <div className="bg-muted p-4 font-medium">Step 2: Switch between Customers and Suppliers</div>
                  <div className="p-4 space-y-4">
                    <p>Use the tabs to switch between Customers and Suppliers views.</p>
                    <div className="flex items-center gap-2 p-2 bg-muted/50 rounded-md">
                      <div className="grid w-full grid-cols-2 rounded-lg border">
                        <div className="flex items-center justify-center py-2 font-medium bg-primary text-primary-foreground">
                          Customers
                        </div>
                        <div className="flex items-center justify-center py-2 text-muted-foreground">Suppliers</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="rounded-lg border overflow-hidden">
                  <div className="bg-muted p-4 font-medium">Step 3: Add a New Customer or Supplier</div>
                  <div className="p-4 space-y-4">
                    <p>Click the "Add Customer" or "Add Supplier" button to create a new entry.</p>
                    <div className="flex justify-end">
                      <Button>
                        <span className="mr-2">+</span>
                        Add Customer
                      </Button>
                    </div>
                    <div className="border rounded-lg p-4 mt-4">
                      <h3 className="font-medium mb-4">Add New Customer</h3>
                      <div className="space-y-3">
                        <div>
                          <label className="text-sm font-medium">Name</label>
                          <div className="h-10 rounded-md border mt-1 px-3 py-2">Acme Corporation</div>
                        </div>
                        <div>
                          <label className="text-sm font-medium">Email</label>
                          <div className="h-10 rounded-md border mt-1 px-3 py-2">contact@acme.com</div>
                        </div>
                        <div>
                          <label className="text-sm font-medium">Phone (optional)</label>
                          <div className="h-10 rounded-md border mt-1 px-3 py-2">555-123-4567</div>
                        </div>
                        <div className="flex justify-end gap-2 mt-4">
                          <Button variant="outline">Cancel</Button>
                          <Button>Add Customer</Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="rounded-lg border overflow-hidden">
                  <div className="bg-muted p-4 font-medium">Step 4: View and Manage Customer/Supplier Cards</div>
                  <div className="p-4 space-y-4">
                    <p>Each customer or supplier is displayed as a card with their information and balance.</p>
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="border rounded-lg">
                        <div className="p-4 border-b">
                          <div className="flex items-center justify-between">
                            <h3 className="font-medium">Acme Corporation</h3>
                            <div className="flex gap-2">
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  width="16"
                                  height="16"
                                  viewBox="0 0 24 24"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="2"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                >
                                  <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z" />
                                </svg>
                              </Button>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  width="16"
                                  height="16"
                                  viewBox="0 0 24 24"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="2"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                >
                                  <path d="M3 6h18" />
                                  <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
                                  <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
                                </svg>
                              </Button>
                            </div>
                          </div>
                          <div className="text-sm text-muted-foreground mt-1">
                            <div>contact@acme.com</div>
                            <div>555-123-4567</div>
                          </div>
                        </div>
                        <div className="p-4">
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span className="text-muted-foreground">Outstanding:</span>
                              <span className="font-medium">$1,500.00</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span className="text-muted-foreground">Invoices:</span>
                              <span className="font-medium">3</span>
                            </div>
                            <div className="mt-4 flex gap-2">
                              <Button variant="outline" size="sm" className="w-full">
                                <FileText className="mr-2 h-4 w-4" />
                                Invoices
                              </Button>
                              <Button size="sm" className="w-full">
                                <span className="mr-2">+</span>
                                New Invoice
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Sales Tab */}
          <TabsContent value="sales" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <FileText className="mr-2 h-5 w-5" />
                  Sales & Invoices
                </CardTitle>
                <CardDescription>Manage your sales invoices and track payments</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="rounded-lg border overflow-hidden">
                  <div className="bg-muted p-4 font-medium">Step 1: Navigate to Sales</div>
                  <div className="p-4 space-y-4">
                    <p>Click on the "Sales" link in the main navigation bar.</p>
                    <div className="flex items-center gap-2 p-2 bg-muted/50 rounded-md">
                      <div className="flex h-10 items-center gap-4 border-b bg-background px-4">
                        <span className="font-semibold">FinanceTrack</span>
                        <span className="text-sm text-muted-foreground underline">Dashboard</span>
                        <span className="text-sm text-muted-foreground underline">Transactions</span>
                        <span className="text-sm font-medium underline-offset-4 hover:text-foreground hover:underline">
                          Sales
                        </span>
                        <span className="text-sm text-muted-foreground underline">Purchases</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="rounded-lg border overflow-hidden">
                  <div className="bg-muted p-4 font-medium">Step 2: Create a New Invoice</div>
                  <div className="p-4 space-y-4">
                    <p>Click the "New Invoice" button to create a new invoice.</p>
                    <div className="flex justify-end">
                      <Button>
                        <span className="mr-2">+</span>
                        New Invoice
                      </Button>
                    </div>
                    <div className="border rounded-lg p-4 mt-4">
                      <h3 className="font-medium mb-4">New Invoice</h3>
                      <div className="space-y-3">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="text-sm font-medium">Customer</label>
                            <div className="h-10 rounded-md border mt-1 px-3 py-2">Acme Corporation</div>
                          </div>
                          <div>
                            <label className="text-sm font-medium">Invoice Number</label>
                            <div className="h-10 rounded-md border mt-1 px-3 py-2">INV-001</div>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="text-sm font-medium">Issue Date</label>
                            <div className="h-10 rounded-md border mt-1 px-3 py-2">2023-04-01</div>
                          </div>
                          <div>
                            <label className="text-sm font-medium">Due Date</label>
                            <div className="h-10 rounded-md border mt-1 px-3 py-2">2023-05-01</div>
                          </div>
                        </div>
                        <div>
                          <label className="text-sm font-medium">Items</label>
                          <div className="border rounded-md mt-1 overflow-hidden">
                            <table className="w-full">
                              <thead className="bg-muted">
                                <tr>
                                  <th className="p-2 text-left">Description</th>
                                  <th className="p-2 text-right">Qty</th>
                                  <th className="p-2 text-right">Price</th>
                                  <th className="p-2 text-right">Total</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr className="border-t">
                                  <td className="p-2">Web Development Services</td>
                                  <td className="p-2 text-right">10</td>
                                  <td className="p-2 text-right">$150.00</td>
                                  <td className="p-2 text-right">$1,500.00</td>
                                </tr>
                              </tbody>
                              <tfoot className="bg-muted/50">
                                <tr className="border-t">
                                  <td colSpan={3} className="p-2 text-right font-medium">
                                    Total:
                                  </td>
                                  <td className="p-2 text-right font-medium">$1,500.00</td>
                                </tr>
                              </tfoot>
                            </table>
                          </div>
                        </div>
                        <div className="flex justify-end gap-2 mt-4">
                          <Button variant="outline">Cancel</Button>
                          <Button>Save Invoice</Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="rounded-lg border overflow-hidden">
                  <div className="bg-muted p-4 font-medium">Step 3: Manage Invoices</div>
                  <div className="p-4 space-y-4">
                    <p>View, edit, and manage your invoices from the list.</p>
                    <div className="border rounded-md overflow-hidden">
                      <table className="w-full">
                        <thead className="bg-muted">
                          <tr>
                            <th className="p-2 text-left">Invoice #</th>
                            <th className="p-2 text-left">Customer</th>
                            <th className="p-2 text-left">Date</th>
                            <th className="p-2 text-left">Status</th>
                            <th className="p-2 text-right">Amount</th>
                            <th className="p-2 text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr className="border-t">
                            <td className="p-2 font-medium">INV-001</td>
                            <td className="p-2">Acme Corporation</td>
                            <td className="p-2">Apr 1, 2023</td>
                            <td className="p-2">
                              <span className="inline-flex items-center rounded-md bg-blue-50 px-2 py-1 text-xs font-medium text-blue-700 ring-1 ring-inset ring-blue-600/20">
                                Sent
                              </span>
                            </td>
                            <td className="p-2 text-right">$1,500.00</td>
                            <td className="p-2 text-right">
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  width="16"
                                  height="16"
                                  viewBox="0 0 24 24"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="2"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                >
                                  <circle cx="12" cy="12" r="1" />
                                  <circle cx="19" cy="12" r="1" />
                                  <circle cx="5" cy="12" r="1" />
                                </svg>
                              </Button>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>

                <div className="rounded-lg border overflow-hidden">
                  <div className="bg-muted p-4 font-medium">Step 4: Invoice Actions</div>
                  <div className="p-4 space-y-4">
                    <p>Use the actions menu to perform operations on invoices.</p>
                    <div className="border rounded-md p-4">
                      <div className="flex flex-col gap-2">
                        <div className="flex items-center gap-2 p-2 hover:bg-muted/50 rounded-md cursor-pointer">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
                            <circle cx="12" cy="12" r="3" />
                          </svg>
                          <span>View</span>
                        </div>
                        <div className="flex items-center gap-2 p-2 hover:bg-muted/50 rounded-md cursor-pointer">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                            <path d="M14 2v6h6" />
                            <path d="M16 13H8" />
                            <path d="M16 17H8" />
                            <path d="M10 9H8" />
                          </svg>
                          <span>Edit</span>
                        </div>
                        <div className="flex items-center gap-2 p-2 hover:bg-muted/50 rounded-md cursor-pointer">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <path d="m22 2-7 20-4-9-9-4Z" />
                            <path d="M22 2 11 13" />
                          </svg>
                          <span>Mark as Sent</span>
                        </div>
                        <div className="flex items-center gap-2 p-2 hover:bg-muted/50 rounded-md cursor-pointer">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <circle cx="12" cy="12" r="10" />
                            <path d="m16 8-8 8" />
                            <path d="m8 8 8 8" />
                          </svg>
                          <span>Delete</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Purchases Tab */}
          <TabsContent value="purchases" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <ShoppingCart className="mr-2 h-5 w-5" />
                  Purchases & Bills
                </CardTitle>
                <CardDescription>Manage your purchase bills and track payments</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="rounded-lg border overflow-hidden">
                  <div className="bg-muted p-4 font-medium">Step 1: Navigate to Purchases</div>
                  <div className="p-4 space-y-4">
                    <p>Click on the "Purchases" link in the main navigation bar.</p>
                    <div className="flex items-center gap-2 p-2 bg-muted/50 rounded-md">
                      <div className="flex h-10 items-center gap-4 border-b bg-background px-4">
                        <span className="font-semibold">FinanceTrack</span>
                        <span className="text-sm text-muted-foreground underline">Dashboard</span>
                        <span className="text-sm text-muted-foreground underline">Transactions</span>
                        <span className="text-sm text-muted-foreground underline">Sales</span>
                        <span className="text-sm font-medium underline-offset-4 hover:text-foreground hover:underline">
                          Purchases
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="rounded-lg border overflow-hidden">
                  <div className="bg-muted p-4 font-medium">Step 2: Create a New Bill</div>
                  <div className="p-4 space-y-4">
                    <p>Click the "New Bill" button to create a new bill.</p>
                    <div className="flex justify-end">
                      <Button>
                        <span className="mr-2">+</span>
                        New Bill
                      </Button>
                    </div>
                    <div className="border rounded-lg p-4 mt-4">
                      <h3 className="font-medium mb-4">New Bill</h3>
                      <div className="space-y-3">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="text-sm font-medium">Supplier</label>
                            <div className="h-10 rounded-md border mt-1 px-3 py-2">Office Supplies Inc</div>
                          </div>
                          <div>
                            <label className="text-sm font-medium">Bill Number</label>
                            <div className="h-10 rounded-md border mt-1 px-3 py-2">BILL-001</div>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="text-sm font-medium">Issue Date</label>
                            <div className="h-10 rounded-md border mt-1 px-3 py-2">2023-04-05</div>
                          </div>
                          <div>
                            <label className="text-sm font-medium">Due Date</label>
                            <div className="h-10 rounded-md border mt-1 px-3 py-2">2023-05-05</div>
                          </div>
                        </div>
                        <div>
                          <label className="text-sm font-medium">Items</label>
                          <div className="border rounded-md mt-1 overflow-hidden">
                            <table className="w-full">
                              <thead className="bg-muted">
                                <tr>
                                  <th className="p-2 text-left">Description</th>
                                  <th className="p-2 text-right">Qty</th>
                                  <th className="p-2 text-right">Price</th>
                                  <th className="p-2 text-right">Total</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr className="border-t">
                                  <td className="p-2">Office Supplies</td>
                                  <td className="p-2 text-right">1</td>
                                  <td className="p-2 text-right">$242.00</td>
                                  <td className="p-2 text-right">$242.00</td>
                                </tr>
                              </tbody>
                              <tfoot className="bg-muted/50">
                                <tr className="border-t">
                                  <td colSpan={3} className="p-2 text-right font-medium">
                                    Total:
                                  </td>
                                  <td className="p-2 text-right font-medium">$242.00</td>
                                </tr>
                              </tfoot>
                            </table>
                          </div>
                        </div>
                        <div className="flex justify-end gap-2 mt-4">
                          <Button variant="outline">Cancel</Button>
                          <Button>Save Bill</Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="rounded-lg border overflow-hidden">
                  <div className="bg-muted p-4 font-medium">Step 3: Manage Bills</div>
                  <div className="p-4 space-y-4">
                    <p>View, edit, and manage your bills from the list.</p>
                    <div className="border rounded-md overflow-hidden">
                      <table className="w-full">
                        <thead className="bg-muted">
                          <tr>
                            <th className="p-2 text-left">Bill #</th>
                            <th className="p-2 text-left">Supplier</th>
                            <th className="p-2 text-left">Date</th>
                            <th className="p-2 text-left">Status</th>
                            <th className="p-2 text-right">Amount</th>
                            <th className="p-2 text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr className="border-t">
                            <td className="p-2 font-medium">BILL-001</td>
                            <td className="p-2">Office Supplies Inc</td>
                            <td className="p-2">Apr 5, 2023</td>
                            <td className="p-2">
                              <span className="inline-flex items-center rounded-md bg-blue-50 px-2 py-1 text-xs font-medium text-blue-700 ring-1 ring-inset ring-blue-600/20">
                                Sent
                              </span>
                            </td>
                            <td className="p-2 text-right">$242.00</td>
                            <td className="p-2 text-right">
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  width="16"
                                  height="16"
                                  viewBox="0 0 24 24"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="2"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                >
                                  <circle cx="12" cy="12" r="1" />
                                  <circle cx="19" cy="12" r="1" />
                                  <circle cx="5" cy="12" r="1" />
                                </svg>
                              </Button>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Reports Tab */}
          <TabsContent value="reports" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="mr-2 h-5 w-5" />
                  Financial Reports
                </CardTitle>
                <CardDescription>Generate and view your financial reports</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="rounded-lg border overflow-hidden">
                  <div className="bg-muted p-4 font-medium">Step 1: Navigate to Reports</div>
                  <div className="p-4 space-y-4">
                    <p>Click on the "Reports" link in the main navigation bar.</p>
                    <div className="flex items-center gap-2 p-2 bg-muted/50 rounded-md">
                      <div className="flex h-10 items-center gap-4 border-b bg-background px-4">
                        <span className="font-semibold">FinanceTrack</span>
                        <span className="text-sm text-muted-foreground underline">Dashboard</span>
                        <span className="text-sm text-muted-foreground underline">Transactions</span>
                        <span className="text-sm font-medium underline-offset-4 hover:text-foreground hover:underline">
                          Reports
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="rounded-lg border overflow-hidden">
                  <div className="bg-muted p-4 font-medium">Step 2: Configure Report Options</div>
                  <div className="p-4 space-y-4">
                    <p>Use the sidebar to configure your report settings.</p>
                    <div className="border rounded-lg p-4">
                      <h3 className="font-medium mb-4">Report Options</h3>
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Date Range</label>
                          <div className="h-10 rounded-md border px-3 py-2 flex items-center justify-between">
                            <span>This Month</span>
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="16"
                              height="16"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <path d="m6 9 6 6 6-6" />
                            </svg>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Comparison</label>
                          <div className="h-10 rounded-md border px-3 py-2 flex items-center justify-between">
                            <span>Previous Period</span>
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="16"
                              height="16"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <path d="m6 9 6 6 6-6" />
                            </svg>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Categories</label>
                          <div className="h-10 rounded-md border px-3 py-2 flex items-center justify-between">
                            <span>All Categories</span>
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="16"
                              height="16"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <path d="m6 9 6 6 6-6" />
                            </svg>
                          </div>
                        </div>
                        <Button className="w-full">Generate Report</Button>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="rounded-lg border overflow-hidden">
                  <div className="bg-muted p-4 font-medium">Step 3: View Different Report Types</div>
                  <div className="p-4 space-y-4">
                    <p>Use the tabs to switch between different report types.</p>
                    <div className="border rounded-md overflow-hidden">
                      <div className="grid grid-cols-5 border-b">
                        <div className="p-2 text-center font-medium bg-primary text-primary-foreground">Overview</div>
                        <div className="p-2 text-center text-muted-foreground">Income</div>
                        <div className="p-2 text-center text-muted-foreground">Expenses</div>
                        <div className="p-2 text-center text-muted-foreground">Income Statement</div>
                        <div className="p-2 text-center text-muted-foreground">Balance Sheet</div>
                      </div>
                      <div className="p-4">
                        <h3 className="font-medium mb-4">Financial Summary</h3>
                        <div className="grid gap-4 md:grid-cols-3">
                          <div className="border rounded-lg p-4">
                            <div className="text-sm font-medium text-muted-foreground">Total Income</div>
                            <div className="text-2xl font-bold mt-1">$7,450.00</div>
                            <div className="text-xs text-muted-foreground mt-1">+12.5% from previous period</div>
                          </div>
                          <div className="border rounded-lg p-4">
                            <div className="text-sm font-medium text-muted-foreground">Total Expenses</div>
                            <div className="text-2xl font-bold mt-1">$1,627.21</div>
                            <div className="text-xs text-muted-foreground mt-1">+4.3% from previous period</div>
                          </div>
                          <div className="border rounded-lg p-4">
                            <div className="text-sm font-medium text-muted-foreground">Net Profit</div>
                            <div className="text-2xl font-bold mt-1">$5,822.79</div>
                            <div className="text-xs text-muted-foreground mt-1">+15.2% from previous period</div>
                          </div>
                        </div>
                        <div className="h-64 bg-muted/20 rounded-lg mt-6 flex items-center justify-center">
                          <div className="text-center">
                            <div className="text-muted-foreground">Revenue Chart</div>
                            <div className="text-xs text-muted-foreground mt-1">
                              Income, Expenses, and Profit over time
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="rounded-lg border overflow-hidden">
                  <div className="bg-muted p-4 font-medium">Step 4: View Financial Statements</div>
                  <div className="p-4 space-y-4">
                    <p>Switch to the Income Statement or Balance Sheet tabs to view detailed financial statements.</p>
                    <div className="border rounded-lg p-4">
                      <h3 className="font-medium mb-4">Income Statement</h3>
                      <div className="space-y-4">
                        <div>
                          <h4 className="text-sm font-medium mb-2">Revenue</h4>
                          <div className="space-y-2 pl-4">
                            <div className="flex justify-between">
                              <span>Sales</span>
                              <span>$4,250.00</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Other Income</span>
                              <span>$3,200.00</span>
                            </div>
                            <div className="flex justify-between font-medium border-t pt-2">
                              <span>Total Revenue</span>
                              <span>$7,450.00</span>
                            </div>
                          </div>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium mb-2">Expenses</h4>
                          <div className="space-y-2 pl-4">
                            <div className="flex justify-between">
                              <span>Rent</span>
                              <span>$1,200.00</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Utilities</span>
                              <span>$135.22</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Software</span>
                              <span>$49.99</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Office Supplies</span>
                              <span>$242.00</span>
                            </div>
                            <div className="flex justify-between font-medium border-t pt-2">
                              <span>Total Expenses</span>
                              <span>$1,627.21</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex justify-between font-bold border-t border-b-2 py-4 text-lg">
                          <span>Net Income</span>
                          <span>$5,822.79</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

