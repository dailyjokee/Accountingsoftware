"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useFinance } from "@/context/finance-context"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { DollarSign } from "lucide-react"
import type { TransactionType, TransactionCategory } from "@/lib/types"
import { toast } from "@/hooks/use-toast"

export default function EditTransactionPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const { transactions, updateTransaction, accounts } = useFinance()

  const [type, setType] = useState<TransactionType>("expense")
  const [amount, setAmount] = useState("")
  const [date, setDate] = useState("")
  const [category, setCategory] = useState<TransactionCategory>("other_expense")
  const [payee, setPayee] = useState("")
  const [account, setAccount] = useState("")
  const [notes, setNotes] = useState("")
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const transaction = transactions.find((t) => t.id === params.id)

    if (transaction) {
      setType(transaction.type)
      setAmount(transaction.amount.toString())
      setDate(transaction.date)
      setCategory(transaction.category)
      setPayee(transaction.payee)
      setAccount(transaction.account)
      setNotes(transaction.notes || "")
    } else {
      toast({
        title: "Transaction not found",
        description: "The transaction you're trying to edit doesn't exist.",
        variant: "destructive",
      })
      router.push("/transactions")
    }

    setIsLoading(false)
  }, [params.id, transactions, router])

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) {
      newErrors.amount = "Please enter a valid amount greater than 0"
    }

    if (!date) {
      newErrors.date = "Please select a date"
    }

    if (!category) {
      newErrors.category = "Please select a category"
    }

    if (!payee.trim()) {
      newErrors.payee = "Please enter a payee/payer name"
    }

    if (!account) {
      newErrors.account = "Please select an account"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      return
    }

    updateTransaction(params.id, {
      type,
      amount: Number(amount),
      date,
      category,
      payee,
      account,
      notes,
    })

    toast({
      title: "Transaction updated",
      description: "Your transaction has been updated successfully.",
    })

    router.push("/transactions")
  }

  // Filter categories based on transaction type
  const getCategories = () => {
    if (type === "income") {
      return [
        { value: "salary", label: "Salary" },
        { value: "freelance", label: "Freelance" },
        { value: "interest", label: "Interest" },
        { value: "other_income", label: "Other Income" },
      ]
    } else if (type === "expense") {
      return [
        { value: "rent", label: "Rent" },
        { value: "utilities", label: "Utilities" },
        { value: "groceries", label: "Groceries" },
        { value: "entertainment", label: "Entertainment" },
        { value: "transportation", label: "Transportation" },
        { value: "office_supplies", label: "Office Supplies" },
        { value: "software", label: "Software" },
        { value: "other_expense", label: "Other Expense" },
      ]
    } else {
      return [{ value: "transfer", label: "Transfer" }]
    }
  }

  if (isLoading) {
    return (
      <div className="flex min-h-screen w-full flex-col">
        <Header />
        <main className="flex flex-1 items-center justify-center">
          <p>Loading transaction...</p>
        </main>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen w-full flex-col">
      <Header />
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="mx-auto w-full max-w-md">
          <Card>
            <form onSubmit={handleSubmit}>
              <CardHeader>
                <CardTitle>Edit Transaction</CardTitle>
                <CardDescription>Update the details of your transaction.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="type">Transaction Type</Label>
                  <Select
                    value={type}
                    onValueChange={(value: TransactionType) => {
                      setType(value)
                      // Reset category when type changes
                      if (value === "income") {
                        setCategory("salary")
                      } else if (value === "expense") {
                        setCategory("other_expense")
                      } else {
                        setCategory("transfer" as TransactionCategory)
                      }
                    }}
                  >
                    <SelectTrigger id="type">
                      <SelectValue placeholder="Select transaction type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="income">Income</SelectItem>
                      <SelectItem value="expense">Expense</SelectItem>
                      <SelectItem value="transfer">Transfer</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="amount">Amount</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="amount"
                      type="number"
                      step="0.01"
                      placeholder="0.00"
                      className="pl-
                      step=&quot;0.01&quot;"
                      placeholder="0.00"
                      className="pl-8"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                    />
                  </div>
                  {errors.amount && <p className="text-sm text-red-500">{errors.amount}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="date">Date</Label>
                  <Input id="date" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
                  {errors.date && <p className="text-sm text-red-500">{errors.date}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Select value={category} onValueChange={(value: TransactionCategory) => setCategory(value)}>
                    <SelectTrigger id="category">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {getCategories().map((cat) => (
                        <SelectItem key={cat.value} value={cat.value as string}>
                          {cat.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.category && <p className="text-sm text-red-500">{errors.category}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="payee">Payee/Payer</Label>
                  <Input id="payee" placeholder="Enter name" value={payee} onChange={(e) => setPayee(e.target.value)} />
                  {errors.payee && <p className="text-sm text-red-500">{errors.payee}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="account">Account</Label>
                  <Select value={account} onValueChange={setAccount}>
                    <SelectTrigger id="account">
                      <SelectValue placeholder="Select account" />
                    </SelectTrigger>
                    <SelectContent>
                      {accounts.map((acc) => (
                        <SelectItem key={acc.id} value={acc.id}>
                          {acc.name} ({acc.type})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.account && <p className="text-sm text-red-500">{errors.account}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="notes">Notes</Label>
                  <Textarea
                    id="notes"
                    placeholder="Add any additional details"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                  />
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button type="button" variant="outline" onClick={() => router.back()}>
                  Cancel
                </Button>
                <Button type="submit">Update Transaction</Button>
              </CardFooter>
            </form>
          </Card>
        </div>
      </main>
    </div>
  )
}

