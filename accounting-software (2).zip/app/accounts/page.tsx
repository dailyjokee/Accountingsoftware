"use client"

import { useState } from "react"
import { useFinance } from "@/context/finance-context"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Plus, Pencil, Trash2 } from "lucide-react"
import { formatCurrency } from "@/lib/utils"
import { toast } from "@/hooks/use-toast"
import { ExportButton } from "@/components/export-button"

export default function AccountsPage() {
  const { accounts, addAccount, updateAccount, deleteAccount } = useFinance()

  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [newAccountName, setNewAccountName] = useState("")
  const [newAccountType, setNewAccountType] = useState("checking")
  const [newAccountBalance, setNewAccountBalance] = useState("")
  const [editAccountId, setEditAccountId] = useState("")
  const [editAccountName, setEditAccountName] = useState("")
  const [editAccountType, setEditAccountType] = useState("")
  const [editAccountBalance, setEditAccountBalance] = useState("")
  const [errors, setErrors] = useState<Record<string, string>>({})

  const validateAccountForm = (isEdit: boolean) => {
    const newErrors: Record<string, string> = {}

    const name = isEdit ? editAccountName : newAccountName
    const balance = isEdit ? editAccountBalance : newAccountBalance

    if (!name.trim()) {
      newErrors.name = "Please enter an account name"
    }

    if (!balance || isNaN(Number(balance))) {
      newErrors.balance = "Please enter a valid balance"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleAddAccount = () => {
    if (!validateAccountForm(false)) {
      return
    }

    addAccount({
      name: newAccountName,
      type: newAccountType as "checking" | "savings" | "credit" | "cash",
      balance: Number(newAccountBalance),
    })

    toast({
      title: "Account added",
      description: "Your account has been added successfully.",
    })

    setIsAddDialogOpen(false)
    setNewAccountName("")
    setNewAccountType("checking")
    setNewAccountBalance("")
  }

  const openEditDialog = (accountId: string) => {
    const account = accounts.find((a) => a.id === accountId)
    if (account) {
      setEditAccountId(account.id)
      setEditAccountName(account.name)
      setEditAccountType(account.type)
      setEditAccountBalance(account.balance.toString())
      setIsEditDialogOpen(true)
    }
  }

  const handleEditAccountInner = () => {
    if (!validateAccountForm(true)) {
      return
    }

    updateAccount(editAccountId, {
      name: editAccountName,
      type: editAccountType as "checking" | "savings" | "credit" | "cash",
      balance: Number(editAccountBalance),
    })

    toast({
      title: "Account updated",
      description: "Your account has been updated successfully.",
    })

    setIsEditDialogOpen(false)
  }

  const handleDeleteAccount = (accountId: string) => {
    deleteAccount(accountId)
  }

  const getAccountTypeColor = (type: string) => {
    switch (type) {
      case "checking":
        return "bg-blue-100 text-blue-800"
      case "savings":
        return "bg-green-100 text-green-800"
      case "credit":
        return "bg-red-100 text-red-800"
      case "cash":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const handleEditAccount = (accountId: string) => {
    openEditDialog(accountId)
  }

  return (
    <div className="flex min-h-screen w-full flex-col">
      <Header />
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-semibold md:text-2xl">Accounts</h1>
          <div className="flex items-center gap-2">
            <ExportButton
              data={accounts}
              columns={[
                { key: "name", label: "Account Name" },
                { key: "type", label: "Type" },
                { key: "balance", label: "Balance" },
              ]}
              filename="accounts"
            />
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Add Account
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Account</DialogTitle>
                  <DialogDescription>Enter the details for your new financial account.</DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="name">Account Name</Label>
                    <Input
                      id="name"
                      placeholder="e.g., Main Checking"
                      value={newAccountName}
                      onChange={(e) => setNewAccountName(e.target.value)}
                    />
                    {errors.name && <p className="text-sm text-red-500">{errors.name}</p>}
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="type">Account Type</Label>
                    <Select value={newAccountType} onValueChange={setNewAccountType}>
                      <SelectTrigger id="type">
                        <SelectValue placeholder="Select account type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="checking">Checking</SelectItem>
                        <SelectItem value="savings">Savings</SelectItem>
                        <SelectItem value="credit">Credit Card</SelectItem>
                        <SelectItem value="cash">Cash</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="balance">Current Balance</Label>
                    <Input
                      id="balance"
                      type="number"
                      step="0.01"
                      placeholder="0.00"
                      value={newAccountBalance}
                      onChange={(e) => setNewAccountBalance(e.target.value)}
                    />
                    {errors.balance && <p className="text-sm text-red-500">{errors.balance}</p>}
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleAddAccount}>Add Account</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {accounts.map((account) => (
            <Card key={account.id}>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle>{account.name}</CardTitle>
                  <div className="flex gap-2">
                    <Button variant="ghost" size="icon" onClick={() => handleEditAccount(account.id)}>
                      <Pencil className="h-4 w-4" />
                      <span className="sr-only">Edit</span>
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <Trash2 className="h-4 w-4" />
                          <span className="sr-only">Delete</span>
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                          <AlertDialogDescription>
                            This will permanently delete this account. This action cannot be undone.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction onClick={() => handleDeleteAccount(account.id)}>Delete</AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
                <CardDescription>
                  <span
                    className={`inline-flex items-center rounded-md px-2 py-1 text-xs font-medium ${getAccountTypeColor(account.type)}`}
                  >
                    {account.type.charAt(0).toUpperCase() + account.type.slice(1)}
                  </span>
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatCurrency(account.balance)}</div>
              </CardContent>
            </Card>
          ))}
          {accounts.length === 0 && (
            <Card className="col-span-full">
              <CardContent className="flex flex-col items-center justify-center p-6">
                <p className="mb-4 text-center text-muted-foreground">
                  No accounts found. Add your first account to get started.
                </p>
                <DialogTrigger asChild>
                  <Button onClick={() => setIsAddDialogOpen(true)}>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Account
                  </Button>
                </DialogTrigger>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Account</DialogTitle>
            <DialogDescription>Update the details for your account.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-name">Account Name</Label>
              <Input
                id="edit-name"
                placeholder="e.g., Main Checking"
                value={editAccountName}
                onChange={(e) => setEditAccountName(e.target.value)}
              />
              {errors.name && <p className="text-sm text-red-500">{errors.name}</p>}
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-type">Account Type</Label>
              <Select value={editAccountType} onValueChange={setEditAccountType}>
                <SelectTrigger id="edit-type">
                  <SelectValue placeholder="Select account type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="checking">Checking</SelectItem>
                  <SelectItem value="savings">Savings</SelectItem>
                  <SelectItem value="credit">Credit Card</SelectItem>
                  <SelectItem value="cash">Cash</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-balance">Current Balance</Label>
              <Input
                id="edit-balance"
                type="number"
                step="0.01"
                placeholder="0.00"
                value={editAccountBalance}
                onChange={(e) => setEditAccountBalance(e.target.value)}
              />
              {errors.balance && <p className="text-sm text-red-500">{errors.balance}</p>}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleEditAccountInner}>Update Account</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

