"use client"

import { useState, useEffect, useCallback } from "react"
import { useFinance } from "@/context/finance-context"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { formatCurrency, getCategoryLabel } from "@/lib/utils"
import {
  PieChart,
  Pie,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell,
} from "recharts"
import { toast } from "@/components/ui/use-toast"
import { ExportButton } from "@/components/export-button"
import { PrintButton } from "@/components/print-button"

export default function ReportsPage() {
  const { transactions, summary, generateBalanceSheet, generateIncomeStatement, generateCashFlowStatement } =
    useFinance()

  const [dateRange, setDateRange] = useState("month")
  const [comparison, setComparison] = useState("previous")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [chartData, setChartData] = useState<any[]>([])
  const [incomePieData, setIncomePieData] = useState<any[]>([])
  const [expensePieData, setExpensePieData] = useState<any[]>([])
  const [balanceSheet, setBalanceSheet] = useState<any>(null)
  const [incomeStatement, setIncomeStatement] = useState<any>(null)
  const [cashFlowStatement, setCashFlowStatement] = useState<any>(null)
  const [isClient, setIsClient] = useState(false)

  // Fix for hydration issues
  useEffect(() => {
    setIsClient(true)
  }, [])

  // Memoize these functions to prevent recreation on every render
  const getStartDate = useCallback(() => {
    const now = new Date()
    const startDate = new Date()

    if (dateRange === "week") {
      startDate.setDate(now.getDate() - 7)
    } else if (dateRange === "month") {
      startDate.setMonth(now.getMonth() - 1)
    } else if (dateRange === "quarter") {
      startDate.setMonth(now.getMonth() - 3)
    } else if (dateRange === "year") {
      startDate.setFullYear(now.getFullYear() - 1)
    }

    return startDate.toISOString().split("T")[0]
  }, [dateRange])

  const getCurrentDate = useCallback(() => {
    return new Date().toISOString().split("T")[0]
  }, [])

  // Initialize financial statements only once on component mount
  useEffect(() => {
    setBalanceSheet(generateBalanceSheet())
    setIncomeStatement(generateIncomeStatement(getStartDate(), getCurrentDate()))
    setCashFlowStatement(generateCashFlowStatement(getStartDate(), getCurrentDate()))
  }, [generateBalanceSheet, generateIncomeStatement, generateCashFlowStatement, getStartDate, getCurrentDate])

  // Update chart data when summary changes
  useEffect(() => {
    if (summary.monthlyData.length > 0) {
      const formattedData = summary.monthlyData.map((item) => ({
        name: formatMonthYear(item.month),
        income: item.income,
        expenses: item.expenses,
        profit: item.income - item.expenses,
      }))
      setChartData(formattedData)
    }

    // Process income by category for pie chart
    const incomeData = Object.entries(summary.incomeByCategory).map(([category, amount]) => ({
      name: getCategoryLabel(category),
      value: amount,
    }))
    setIncomePieData(incomeData)

    // Process expenses by category for pie chart
    const expenseData = Object.entries(summary.expensesByCategory).map(([category, amount]) => ({
      name: getCategoryLabel(category),
      value: amount,
    }))
    setExpensePieData(expenseData)
  }, [summary])

  const formatMonthYear = (dateString: string) => {
    const [year, month] = dateString.split("-")
    const date = new Date(Number.parseInt(year), Number.parseInt(month) - 1)
    return date.toLocaleDateString("en-US", { month: "short", year: "numeric" })
  }

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8", "#82CA9D", "#FF7300", "#A4DE6C"]

  const handleGenerateReport = () => {
    // Update financial statements based on selected date range
    setIncomeStatement(generateIncomeStatement(getStartDate(), getCurrentDate()))
    setCashFlowStatement(generateCashFlowStatement(getStartDate(), getCurrentDate()))

    toast({
      title: "Reports Generated",
      description: `Financial reports for ${dateRange} have been generated.`,
    })
  }

  if (!balanceSheet || !incomeStatement || !cashFlowStatement) {
    return <div>Loading...</div>
  }

  return (
    <div className="flex min-h-screen w-full flex-col">
      <Header />
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-semibold md:text-2xl">Financial Reports</h1>
          <div className="flex items-center gap-2">
            <PrintButton />
            <ExportButton
              data={summary.monthlyData}
              columns={[
                { key: "month", label: "Month" },
                { key: "income", label: "Income" },
                { key: "expenses", label: "Expenses" },
              ]}
              filename="financial-reports"
            />
          </div>
        </div>
        <div className="flex flex-col gap-4 md:flex-row">
          <Card className="w-full md:w-64">
            <CardHeader>
              <CardTitle>Report Options</CardTitle>
              <CardDescription>Configure your report settings.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Date Range</label>
                <Select value={dateRange} onValueChange={setDateRange}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select date range" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="week">This Week</SelectItem>
                    <SelectItem value="month">This Month</SelectItem>
                    <SelectItem value="quarter">This Quarter</SelectItem>
                    <SelectItem value="year">This Year</SelectItem>
                    <SelectItem value="custom">Custom Range</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Comparison</label>
                <Select value={comparison} onValueChange={setComparison}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select comparison" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    <SelectItem value="previous">Previous Period</SelectItem>
                    <SelectItem value="year">Same Period Last Year</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Categories</label>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    <SelectItem value="income">Income Only</SelectItem>
                    <SelectItem value="expenses">Expenses Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button className="w-full" onClick={handleGenerateReport}>
                Generate Report
              </Button>
            </CardContent>
          </Card>
          <div className="flex-1">
            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="grid w-full grid-cols-5">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="income">Income</TabsTrigger>
                <TabsTrigger value="expenses">Expenses</TabsTrigger>
                <TabsTrigger value="income-statement">Income Statement</TabsTrigger>
                <TabsTrigger value="balance-sheet">Balance Sheet</TabsTrigger>
              </TabsList>

              {/* Overview Tab */}
              <TabsContent value="overview" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Financial Summary</CardTitle>
                    <CardDescription>Overview of your financial performance for the current period.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm font-medium">Total Income</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">{formatCurrency(summary.totalIncome)}</div>
                          <p className="text-xs text-muted-foreground">+12.5% from previous period</p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm font-medium">Total Expenses</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">{formatCurrency(summary.totalExpenses)}</div>
                          <p className="text-xs text-muted-foreground">+4.3% from previous period</p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm font-medium">Net Profit</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">{formatCurrency(summary.netProfit)}</div>
                          <p className="text-xs text-muted-foreground">+15.2% from previous period</p>
                        </CardContent>
                      </Card>
                    </div>
                    {isClient && chartData.length > 0 && (
                      <div className="mt-6 h-[300px] w-full">
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart
                            data={chartData}
                            margin={{
                              top: 5,
                              right: 30,
                              left: 20,
                              bottom: 5,
                            }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="name" />
                            <YAxis />
                            <Tooltip formatter={(value) => formatCurrency(value as number)} />
                            <Legend />
                            <Line type="monotone" dataKey="income" stroke="#8884d8" activeDot={{ r: 8 }} />
                            <Line type="monotone" dataKey="expenses" stroke="#82ca9d" />
                            <Line type="monotone" dataKey="profit" stroke="#ff7300" />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Income Tab */}
              <TabsContent value="income" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Income Analysis</CardTitle>
                    <CardDescription>Detailed breakdown of your income sources.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-4 md:grid-cols-2">
                      {isClient && incomePieData.length > 0 && (
                        <div className="h-[300px] w-full">
                          <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                              <Pie
                                data={incomePieData}
                                cx="50%"
                                cy="50%"
                                labelLine={false}
                                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                                outerRadius={80}
                                fill="#8884d8"
                                dataKey="value"
                              >
                                {incomePieData.map((entry, index) => (
                                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                              </Pie>
                              <Tooltip formatter={(value) => formatCurrency(value as number)} />
                              <Legend />
                            </PieChart>
                          </ResponsiveContainer>
                        </div>
                      )}
                      {isClient && chartData.length > 0 && (
                        <div className="h-[300px] w-full">
                          <ResponsiveContainer width="100%" height="100%">
                            <LineChart
                              data={chartData}
                              margin={{
                                top: 5,
                                right: 30,
                                left: 20,
                                bottom: 5,
                              }}
                            >
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="name" />
                              <YAxis />
                              <Tooltip formatter={(value) => formatCurrency(value as number)} />
                              <Legend />
                              <Line type="monotone" dataKey="income" stroke="#8884d8" activeDot={{ r: 8 }} />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>
                      )}
                    </div>
                    <div className="mt-6 rounded-md border">
                      <div className="grid grid-cols-3 gap-4 p-4 text-sm font-medium">
                        <div>Source</div>
                        <div>Amount</div>
                        <div>% of Total</div>
                      </div>
                      <div className="divide-y">
                        {incomePieData.map((item, index) => (
                          <div key={index} className="grid grid-cols-3 gap-4 p-4 text-sm">
                            <div>{item.name}</div>
                            <div>{formatCurrency(item.value)}</div>
                            <div>{((item.value / summary.totalIncome) * 100).toFixed(1)}%</div>
                          </div>
                        ))}
                        {incomePieData.length === 0 && (
                          <div className="p-4 text-center text-muted-foreground">No income data available</div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Expenses Tab */}
              <TabsContent value="expenses" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Expense Analysis</CardTitle>
                    <CardDescription>Detailed breakdown of your expenses.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-4 md:grid-cols-2">
                      {isClient && expensePieData.length > 0 && (
                        <div className="h-[300px] w-full">
                          <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                              <Pie
                                data={expensePieData}
                                cx="50%"
                                cy="50%"
                                labelLine={false}
                                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                                outerRadius={80}
                                fill="#8884d8"
                                dataKey="value"
                              >
                                {expensePieData.map((entry, index) => (
                                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                              </Pie>
                              <Tooltip formatter={(value) => formatCurrency(value as number)} />
                              <Legend />
                            </PieChart>
                          </ResponsiveContainer>
                        </div>
                      )}
                      {isClient && chartData.length > 0 && (
                        <div className="h-[300px] w-full">
                          <ResponsiveContainer width="100%" height="100%">
                            <BarChart
                              data={chartData}
                              margin={{
                                top: 5,
                                right: 30,
                                left: 20,
                                bottom: 5,
                              }}
                            >
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="name" />
                              <YAxis />
                              <Tooltip formatter={(value) => formatCurrency(value as number)} />
                              <Legend />
                              <Bar dataKey="expenses" fill="#82ca9d" />
                            </BarChart>
                          </ResponsiveContainer>
                        </div>
                      )}
                    </div>
                    <div className="mt-6 rounded-md border">
                      <div className="grid grid-cols-3 gap-4 p-4 text-sm font-medium">
                        <div>Category</div>
                        <div>Amount</div>
                        <div>% of Total</div>
                      </div>
                      <div className="divide-y">
                        {expensePieData.map((item, index) => (
                          <div key={index} className="grid grid-cols-3 gap-4 p-4 text-sm">
                            <div>{item.name}</div>
                            <div>{formatCurrency(item.value)}</div>
                            <div>{((item.value / summary.totalExpenses) * 100).toFixed(1)}%</div>
                          </div>
                        ))}
                        {expensePieData.length === 0 && (
                          <div className="p-4 text-center text-muted-foreground">No expense data available</div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Income Statement Tab */}
              <TabsContent value="income-statement" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Income Statement</CardTitle>
                    <CardDescription>
                      For the period {formatDate(getStartDate())} to {formatDate(getCurrentDate())}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="rounded-md border">
                      <div className="p-4">
                        <h3 className="text-lg font-semibold mb-4">Revenue</h3>
                        <div className="space-y-2 pl-4">
                          <div className="flex justify-between">
                            <span>Sales</span>
                            <span>{formatCurrency(incomeStatement.revenue.sales)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Other Income</span>
                            <span>{formatCurrency(incomeStatement.revenue.otherIncome)}</span>
                          </div>
                          <div className="flex justify-between font-medium border-t pt-2">
                            <span>Total Revenue</span>
                            <span>{formatCurrency(incomeStatement.revenue.totalRevenue)}</span>
                          </div>
                        </div>

                        <h3 className="text-lg font-semibold mt-6 mb-4">Cost of Goods Sold</h3>
                        <div className="space-y-2 pl-4">
                          <div className="flex justify-between">
                            <span>Cost of Goods Sold</span>
                            <span>{formatCurrency(incomeStatement.expenses.costOfGoodsSold)}</span>
                          </div>
                        </div>

                        <div className="flex justify-between font-medium border-t border-b py-2 my-4">
                          <span>Gross Profit</span>
                          <span>{formatCurrency(incomeStatement.grossProfit)}</span>
                        </div>

                        <h3 className="text-lg font-semibold mt-6 mb-4">Operating Expenses</h3>
                        <div className="space-y-2 pl-4">
                          {Object.entries(incomeStatement.expenses.operatingExpenses).map(([category, amount]) => (
                            <div key={category} className="flex justify-between">
                              <span>{getCategoryLabel(category)}</span>
                              <span>{formatCurrency(amount)}</span>
                            </div>
                          ))}
                          <div className="flex justify-between font-medium border-t pt-2">
                            <span>Total Operating Expenses</span>
                            <span>{formatCurrency(incomeStatement.expenses.totalOperatingExpenses)}</span>
                          </div>
                        </div>

                        <div className="flex justify-between font-medium border-t border-b py-2 my-4">
                          <span>Operating Income</span>
                          <span>{formatCurrency(incomeStatement.operatingIncome)}</span>
                        </div>

                        <div className="flex justify-between font-bold border-t border-b-2 py-4 my-4 text-lg">
                          <span>Net Income</span>
                          <span>{formatCurrency(incomeStatement.netIncome)}</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Balance Sheet Tab */}
              <TabsContent value="balance-sheet" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Balance Sheet</CardTitle>
                    <CardDescription>As of {formatDate(getCurrentDate())}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="rounded-md border">
                      <div className="p-4">
                        <h3 className="text-lg font-semibold mb-4">Assets</h3>

                        <h4 className="font-medium mt-4 mb-2">Current Assets</h4>
                        <div className="space-y-2 pl-4">
                          <div className="flex justify-between">
                            <span>Cash</span>
                            <span>{formatCurrency(balanceSheet.assets.currentAssets.cash)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Accounts Receivable</span>
                            <span>{formatCurrency(balanceSheet.assets.currentAssets.accountsReceivable)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Inventory</span>
                            <span>{formatCurrency(balanceSheet.assets.currentAssets.inventory)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Other Current Assets</span>
                            <span>{formatCurrency(balanceSheet.assets.currentAssets.otherCurrentAssets)}</span>
                          </div>
                          <div className="flex justify-between font-medium border-t pt-2">
                            <span>Total Current Assets</span>
                            <span>{formatCurrency(balanceSheet.assets.currentAssets.totalCurrentAssets)}</span>
                          </div>
                        </div>

                        <h4 className="font-medium mt-4 mb-2">Fixed Assets</h4>
                        <div className="space-y-2 pl-4">
                          <div className="flex justify-between">
                            <span>Property and Equipment</span>
                            <span>{formatCurrency(balanceSheet.assets.fixedAssets.propertyAndEquipment)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Other Fixed Assets</span>
                            <span>{formatCurrency(balanceSheet.assets.fixedAssets.otherFixedAssets)}</span>
                          </div>
                          <div className="flex justify-between font-medium border-t pt-2">
                            <span>Total Fixed Assets</span>
                            <span>{formatCurrency(balanceSheet.assets.fixedAssets.totalFixedAssets)}</span>
                          </div>
                        </div>

                        <div className="flex justify-between font-medium border-t border-b py-2 my-4">
                          <span>Total Assets</span>
                          <span>{formatCurrency(balanceSheet.assets.totalAssets)}</span>
                        </div>

                        <h3 className="text-lg font-semibold mt-6 mb-4">Liabilities</h3>

                        <h4 className="font-medium mt-4 mb-2">Current Liabilities</h4>
                        <div className="space-y-2 pl-4">
                          <div className="flex justify-between">
                            <span>Accounts Payable</span>
                            <span>{formatCurrency(balanceSheet.liabilities.currentLiabilities.accountsPayable)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Short Term Debt</span>
                            <span>{formatCurrency(balanceSheet.liabilities.currentLiabilities.shortTermDebt)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Other Current Liabilities</span>
                            <span>
                              {formatCurrency(balanceSheet.liabilities.currentLiabilities.otherCurrentLiabilities)}
                            </span>
                          </div>
                          <div className="flex justify-between font-medium border-t pt-2">
                            <span>Total Current Liabilities</span>
                            <span>
                              {formatCurrency(balanceSheet.liabilities.currentLiabilities.totalCurrentLiabilities)}
                            </span>
                          </div>
                        </div>

                        <h4 className="font-medium mt-4 mb-2">Long Term Liabilities</h4>
                        <div className="space-y-2 pl-4">
                          <div className="flex justify-between">
                            <span>Long Term Debt</span>
                            <span>{formatCurrency(balanceSheet.liabilities.longTermLiabilities.longTermDebt)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Other Long Term Liabilities</span>
                            <span>
                              {formatCurrency(balanceSheet.liabilities.longTermLiabilities.otherLongTermLiabilities)}
                            </span>
                          </div>
                          <div className="flex justify-between font-medium border-t pt-2">
                            <span>Total Long Term Liabilities</span>
                            <span>
                              {formatCurrency(balanceSheet.liabilities.longTermLiabilities.totalLongTermLiabilities)}
                            </span>
                          </div>
                        </div>

                        <div className="flex justify-between font-medium border-t border-b py-2 my-4">
                          <span>Total Liabilities</span>
                          <span>{formatCurrency(balanceSheet.liabilities.totalLiabilities)}</span>
                        </div>

                        <h3 className="text-lg font-semibold mt-6 mb-4">Equity</h3>
                        <div className="space-y-2 pl-4">
                          <div className="flex justify-between">
                            <span>Capital</span>
                            <span>{formatCurrency(balanceSheet.equity.capital)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Retained Earnings</span>
                            <span>{formatCurrency(balanceSheet.equity.retainedEarnings)}</span>
                          </div>
                          <div className="flex justify-between font-medium border-t pt-2">
                            <span>Total Equity</span>
                            <span>{formatCurrency(balanceSheet.equity.totalEquity)}</span>
                          </div>
                        </div>

                        <div className="flex justify-between font-bold border-t border-b-2 py-4 my-4 text-lg">
                          <span>Total Liabilities and Equity</span>
                          <span>
                            {formatCurrency(
                              balanceSheet.liabilities.totalLiabilities + balanceSheet.equity.totalEquity,
                            )}
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Cash Flow Statement Tab */}
              <TabsContent value="cash-flow" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Cash Flow Statement</CardTitle>
                    <CardDescription>
                      For the period {formatDate(getStartDate())} to {formatDate(getCurrentDate())}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="rounded-md border">
                      <div className="p-4">
                        <h3 className="text-lg font-semibold mb-4">Operating Activities</h3>
                        <div className="space-y-2 pl-4">
                          <div className="flex justify-between">
                            <span>Net Income</span>
                            <span>{formatCurrency(cashFlowStatement.operatingActivities.netIncome)}</span>
                          </div>

                          <h4 className="font-medium mt-4 mb-2">Adjustments</h4>
                          <div className="space-y-2 pl-4">
                            {Object.entries(cashFlowStatement.operatingActivities.adjustments).map(([name, amount]) => (
                              <div key={name} className="flex justify-between">
                                <span>{name.charAt(0).toUpperCase() + name.slice(1)}</span>
                                <span>{formatCurrency(amount)}</span>
                              </div>
                            ))}
                          </div>

                          <h4 className="font-medium mt-4 mb-2">Changes in Working Capital</h4>
                          <div className="space-y-2 pl-4">
                            {Object.entries(cashFlowStatement.operatingActivities.changeInWorkingCapital).map(
                              ([name, amount]) => (
                                <div key={name} className="flex justify-between">
                                  <span>{getCategoryLabel(name)}</span>
                                  <span>{formatCurrency(amount)}</span>
                                </div>
                              ),
                            )}
                          </div>

                          <div className="flex justify-between font-medium border-t pt-2 mt-4">
                            <span>Net Cash from Operating Activities</span>
                            <span>{formatCurrency(cashFlowStatement.operatingActivities.netCashFromOperating)}</span>
                          </div>
                        </div>

                        <h3 className="text-lg font-semibold mt-6 mb-4">Investing Activities</h3>
                        <div className="space-y-2 pl-4">
                          {Object.entries(cashFlowStatement.investingActivities.items).map(([name, amount]) => (
                            <div key={name} className="flex justify-between">
                              <span>{getCategoryLabel(name)}</span>
                              <span>{formatCurrency(amount)}</span>
                            </div>
                          ))}
                          <div className="flex justify-between font-medium border-t pt-2">
                            <span>Net Cash from Investing Activities</span>
                            <span>{formatCurrency(cashFlowStatement.investingActivities.netCashFromInvesting)}</span>
                          </div>
                        </div>

                        <h3 className="text-lg font-semibold mt-6 mb-4">Financing Activities</h3>
                        <div className="space-y-2 pl-4">
                          {Object.entries(cashFlowStatement.financingActivities.items).map(([name, amount]) => (
                            <div key={name} className="flex justify-between">
                              <span>{getCategoryLabel(name)}</span>
                              <span>{formatCurrency(amount)}</span>
                            </div>
                          ))}
                          <div className="flex justify-between font-medium border-t pt-2">
                            <span>Net Cash from Financing Activities</span>
                            <span>{formatCurrency(cashFlowStatement.financingActivities.netCashFromFinancing)}</span>
                          </div>
                        </div>

                        <div className="flex justify-between font-medium border-t border-b py-2 my-4">
                          <span>Net Change in Cash</span>
                          <span>{formatCurrency(cashFlowStatement.netCashChange)}</span>
                        </div>

                        <div className="space-y-2 mt-4">
                          <div className="flex justify-between">
                            <span>Cash at Beginning of Period</span>
                            <span>{formatCurrency(cashFlowStatement.startingCash)}</span>
                          </div>
                          <div className="flex justify-between font-bold">
                            <span>Cash at End of Period</span>
                            <span>{formatCurrency(cashFlowStatement.endingCash)}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
    </div>
  )
}

function formatDate(dateString: string): string {
  const date = new Date(dateString)
  return date.toLocaleDateString()
}

